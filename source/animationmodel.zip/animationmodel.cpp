#include "pch.h"
#include "animationmodel.h"
#include "texturemanager.h"
#include "rendererdraw.h"
#include "renderershader.h"
#include "psomanager.h"
#include "materialpartresolver.h"
#include "material.h"
#include "modelimportutils.h"
#include "toonoutlinebuilder.h"
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <cctype>
#include <cmath>
#include <limits>
static bool logged = false;
using namespace std;
using namespace DirectX;

static const char* GetAssimpTextureTypeName(aiTextureType type)
{
	switch (type)
	{
	case aiTextureType_DIFFUSE: return "DIFFUSE";
	case aiTextureType_SPECULAR: return "SPECULAR";
	case aiTextureType_AMBIENT: return "AMBIENT";
	case aiTextureType_EMISSIVE: return "EMISSIVE";
	case aiTextureType_HEIGHT: return "HEIGHT";
	case aiTextureType_NORMALS: return "NORMALS";
	case aiTextureType_SHININESS: return "SHININESS";
	case aiTextureType_OPACITY: return "OPACITY";
	case aiTextureType_DISPLACEMENT: return "DISPLACEMENT";
	case aiTextureType_LIGHTMAP: return "LIGHTMAP";
	case aiTextureType_REFLECTION: return "REFLECTION";
	case aiTextureType_BASE_COLOR: return "BASE_COLOR";
	case aiTextureType_NORMAL_CAMERA: return "NORMAL_CAMERA";
	case aiTextureType_EMISSION_COLOR: return "EMISSION_COLOR";
	case aiTextureType_METALNESS: return "METALNESS";
	case aiTextureType_DIFFUSE_ROUGHNESS: return "DIFFUSE_ROUGHNESS";
	case aiTextureType_AMBIENT_OCCLUSION: return "AMBIENT_OCCLUSION";
	default: return "UNKNOWN";
	}
}

static void LogAssimpMaterialTexture(const aiMaterial* material, aiTextureType type)
{
	const unsigned int textureCount = material->GetTextureCount(type);
	for (unsigned int i = 0; i < textureCount; ++i)
	{
		aiString path;
		if (material->GetTexture(type, i, &path) == AI_SUCCESS)
		{
			Debug::Log("Texture[%s][%u]: %s\n", GetAssimpTextureTypeName(type), i, path.C_Str());
		}
	}
}

static void LogAssimpModelInfo(const aiScene* scene, const char* fileName, const char* modelKind)
{
	if (!scene)
	{
		return;
	}

	Debug::Log("==== %s model import info: %s ====\n", modelKind, fileName);
	Debug::Log("Scene: meshes=%u, materials=%u, textures=%u, animations=%u\n",
		scene->mNumMeshes, scene->mNumMaterials, scene->mNumTextures, scene->mNumAnimations);

	for (unsigned int i = 0; i < scene->mNumMaterials; ++i)
	{
		const aiMaterial* material = scene->mMaterials[i];
		aiString name;
		aiColor3D diffuse(1.0f, 1.0f, 1.0f);
		aiColor3D specular(0.0f, 0.0f, 0.0f);
		aiColor3D ambient(0.0f, 0.0f, 0.0f);
		aiColor3D emissive(0.0f, 0.0f, 0.0f);
		aiColor4D baseColor(1.0f, 1.0f, 1.0f, 1.0f);
		float opacity = 1.0f;
		float shininess = 0.0f;
		float metallic = 0.0f;
		float roughness = 0.0f;
		int twoSided = 0;

		material->Get(AI_MATKEY_NAME, name);
		material->Get(AI_MATKEY_COLOR_DIFFUSE, diffuse);
		material->Get(AI_MATKEY_COLOR_SPECULAR, specular);
		material->Get(AI_MATKEY_COLOR_AMBIENT, ambient);
		material->Get(AI_MATKEY_COLOR_EMISSIVE, emissive);
		material->Get(AI_MATKEY_BASE_COLOR, baseColor);
		material->Get(AI_MATKEY_OPACITY, opacity);
		material->Get(AI_MATKEY_SHININESS, shininess);
		material->Get(AI_MATKEY_METALLIC_FACTOR, metallic);
		material->Get(AI_MATKEY_ROUGHNESS_FACTOR, roughness);
		material->Get(AI_MATKEY_TWOSIDED, twoSided);

		Debug::Log("  Material[%u]: name='%s', properties=%u\n", i, name.C_Str(), material->mNumProperties);
		Debug::Log("    Diffuse=(%.3f, %.3f, %.3f), Specular=(%.3f, %.3f, %.3f), Ambient=(%.3f, %.3f, %.3f), Emissive=(%.3f, %.3f, %.3f)\n",
			diffuse.r, diffuse.g, diffuse.b, specular.r, specular.g, specular.b,
			ambient.r, ambient.g, ambient.b, emissive.r, emissive.g, emissive.b);
		Debug::Log("    BaseColor=(%.3f, %.3f, %.3f, %.3f), Opacity=%.3f, Shininess=%.3f, Metallic=%.3f, Roughness=%.3f, TwoSided=%d\n",
			baseColor.r, baseColor.g, baseColor.b, baseColor.a, opacity, shininess, metallic, roughness, twoSided);

		const aiTextureType textureTypes[] =
		{
			aiTextureType_DIFFUSE,
			aiTextureType_BASE_COLOR,
			aiTextureType_SPECULAR,
			aiTextureType_NORMALS,
			aiTextureType_NORMAL_CAMERA,
			aiTextureType_METALNESS,
			aiTextureType_DIFFUSE_ROUGHNESS,
			aiTextureType_AMBIENT_OCCLUSION,
			aiTextureType_EMISSIVE,
			aiTextureType_OPACITY,
		};
		for (aiTextureType type : textureTypes)
		{
			LogAssimpMaterialTexture(material, type);
		}
	}

	for (unsigned int i = 0; i < scene->mNumMeshes; ++i)
	{
		const aiMesh* mesh = scene->mMeshes[i];
		if (!mesh)
		{
			Debug::Log("  Mesh[%u]: <null>\n", i);
			continue;
		}

		Debug::Log("  Mesh[%u]: name='%s', material=%u, vertices=%u, faces=%u, bones=%u, normals=%d, texcoord0=%d\n",
			i, mesh->mName.C_Str(), mesh->mMaterialIndex, mesh->mNumVertices, mesh->mNumFaces,
			mesh->mNumBones, mesh->HasNormals() ? 1 : 0, mesh->HasTextureCoords(0) ? 1 : 0);
		Debug::Log("    MaterialPartId=%.0f\n", MaterialPartResolver::ResolveMaterialPartId(scene, mesh));
	}
	Debug::Log("==== end %s model import info ====\n", modelKind);
}

static aiMatrix4x4 MakeAiIdentityMatrix()
{
	return aiMatrix4x4(
		1.0f, 0.0f, 0.0f, 0.0f,
		0.0f, 1.0f, 0.0f, 0.0f,
		0.0f, 0.0f, 1.0f, 0.0f,
		0.0f, 0.0f, 0.0f, 1.0f);
}

static string DecodeAsciiFixedString(const char* data, size_t length)
{
	size_t byteCount = 0;
	while (byteCount < length && data[byteCount] != '\0')
	{
		++byteCount;
	}
	return string(data, byteCount);
}

static string DecodeShiftJisFixedString(const char* data, size_t length)
{
	size_t byteCount = 0;
	while (byteCount < length && data[byteCount] != '\0')
	{
		++byteCount;
	}
	if (byteCount == 0)
	{
		return {};
	}

	int wideLength = MultiByteToWideChar(932, MB_ERR_INVALID_CHARS, data, static_cast<int>(byteCount), nullptr, 0);
	if (wideLength <= 0)
	{
		wideLength = MultiByteToWideChar(932, 0, data, static_cast<int>(byteCount), nullptr, 0);
	}
	if (wideLength <= 0)
	{
		return string(data, byteCount);
	}

	wstring wideText(static_cast<size_t>(wideLength), L'\0');
	MultiByteToWideChar(932, 0, data, static_cast<int>(byteCount), wideText.data(), wideLength);

	const int utf8Length = WideCharToMultiByte(CP_UTF8, 0, wideText.data(), wideLength, nullptr, 0, nullptr, nullptr);
	if (utf8Length <= 0)
	{
		return string(data, byteCount);
	}

	string utf8Text(static_cast<size_t>(utf8Length), '\0');
	WideCharToMultiByte(CP_UTF8, 0, wideText.data(), wideLength, utf8Text.data(), utf8Length, nullptr, nullptr);
	return utf8Text;
}

template <typename T>
static bool ReadBinary(ifstream& stream, T& value)
{
	return static_cast<bool>(stream.read(reinterpret_cast<char*>(&value), sizeof(T)));
}

template <size_t N>
static bool ReadBinaryArray(ifstream& stream, array<char, N>& value)
{
	return static_cast<bool>(stream.read(value.data(), static_cast<streamsize>(value.size())));
}

static uint64_t GetRemainingBytes(ifstream& stream)
{
	const streampos current = stream.tellg();
	if (current < 0)
	{
		return 0;
	}

	stream.seekg(0, ios::end);
	const streampos end = stream.tellg();
	stream.seekg(current, ios::beg);
	if (end < current)
	{
		return 0;
	}
	return static_cast<uint64_t>(end - current);
}

static bool ReadOptionalSectionCount(ifstream& stream, uint32_t& count, const char* sectionName, const char* fileName)
{
	const uint64_t remainingBytes = GetRemainingBytes(stream);
	if (remainingBytes == 0)
	{
		count = 0;
		return true;
	}
	if (remainingBytes < sizeof(uint32_t))
	{
		Debug::Log("ERROR: VMD %s count is truncated: %s\n", sectionName, fileName);
		return false;
	}
	return ReadBinary(stream, count);
}

static bool SkipBinaryBytes(ifstream& stream, uint64_t byteCount, const char* sectionName, const char* fileName)
{
	if (GetRemainingBytes(stream) < byteCount)
	{
		Debug::Log("ERROR: VMD %s data is truncated: %s\n", sectionName, fileName);
		return false;
	}

	stream.seekg(static_cast<streamoff>(byteCount), ios::cur);
	return static_cast<bool>(stream);
}

static float NormalizeVmdInterpolationByte(unsigned char value)
{
	return clamp(static_cast<float>(value) / 127.0f, 0.0f, 1.0f);
}

static float GetYFromXOnBezier(float x, const XMFLOAT2& p1, const XMFLOAT2& p2, uint8_t iterationCount)
{
	x = clamp(x, 0.0f, 1.0f);
	if (fabsf(p1.x - p1.y) < 0.0001f && fabsf(p2.x - p2.y) < 0.0001f)
	{
		return x;
	}

	float t = x;
	const float k0 = 1.0f + 3.0f * p1.x - 3.0f * p2.x;
	const float k1 = 3.0f * p2.x - 6.0f * p1.x;
	const float k2 = 3.0f * p1.x;

	for (uint8_t i = 0; i < iterationCount; ++i)
	{
		const float ft = k0 * t * t * t + k1 * t * t + k2 * t - x;
		if (fabsf(ft) <= 0.00001f)
		{
			break;
		}
		t = clamp(t - ft / 2.0f, 0.0f, 1.0f);
	}

	const float r = 1.0f - t;
	return t * t * t + 3.0f * t * t * r * p2.y + 3.0f * t * r * r * p1.y;
}

static aiVector3D ConvertVmdPositionToAssimpLeftHanded(const aiVector3D& position)
{
	return aiVector3D(position.x, position.y, position.z);
}

static aiQuaternion ConvertVmdRotationToAssimpLeftHanded(aiQuaternion rotation)
{
	//rotation.x = -rotation.x;
	//rotation.y = -rotation.y;
	rotation.Normalize();
	return rotation;
}

static void NormalizeBoneInfluences(GpuSkinVertex& gpuVertex, DeformVertex& deformVertex)
{
	float totalWeight = 0.0f;
	for (int i = 0; i < 4; ++i)
	{
		totalWeight += gpuVertex.BoneWeights[i];
	}

	if (totalWeight <= 0.0f)
	{
		deformVertex.BoneNum = 0;
		for (int i = 0; i < 4; ++i)
		{
			gpuVertex.BoneIndices[i] = 0;
			gpuVertex.BoneWeights[i] = 0.0f;
			deformVertex.BoneName[i].clear();
			deformVertex.BoneWeight[i] = 0.0f;
		}
		return;
	}

	const float invTotalWeight = 1.0f / totalWeight;
	for (int i = 0; i < 4; ++i)
	{
		gpuVertex.BoneWeights[i] *= invTotalWeight;
		deformVertex.BoneWeight[i] *= invTotalWeight;
	}
}

void AnimationModelResource::CreateBone(aiNode* node)
{
	string name = node->mName.C_Str();
	if (node->mParent)
	{
		m_BoneParentMap[name] = node->mParent->mName.C_Str();
	}
	if (m_BoneIndexMap.find(name) == m_BoneIndexMap.end())
	{
		uint32_t idx = (uint32_t)m_BoneNames.size();
		m_BoneNames.push_back(name);
		m_BoneIndexMap[name] = idx;
		const aiMatrix4x4 identity = MakeAiIdentityMatrix();
		Bone bone{};
		bone.Matrix = identity;
		bone.BindLocalMatrix = node->mTransformation;
		bone.AnimationMatrix = node->mTransformation;
		bone.OffsetMatrix = identity;
		m_Bone.emplace(name, bone);
	}

	for (unsigned int n = 0; n < node->mNumChildren; n++)
	{
		CreateBone(node->mChildren[n]);
	}
}

bool AnimationModelResource::Load(const char* fileName, ID3D12Device* device, bool isConvert)
{
	m_pDevice = device;

	unsigned int flags = aiProcessPreset_TargetRealtime_MaxQuality;
	if (isConvert)
	{
		flags |= aiProcess_ConvertToLeftHanded;
	}
	m_AiScene = ModelImportUtils::ImportScene(fileName, flags);
	if (!m_AiScene)
	{
		Debug::Log("ERROR: Failed to load animation model: %s (%s)\n", fileName, aiGetErrorString());
		return false;
	}
	LogAssimpModelInfo(m_AiScene, fileName, "Animation");

	m_Meshes.resize(m_AiScene->mNumMeshes);
	m_DeformVertex.resize(m_AiScene->mNumMeshes);
	m_GpuSkinVertices.resize(m_AiScene->mNumMeshes);
	m_BaseGpuSkinVertices.resize(m_AiScene->mNumMeshes);
	m_TeoGpuSkinVertices.resize(m_AiScene->mNumMeshes);
	m_TeoGpuSkinVerticesByMode.resize(m_AiScene->mNumMeshes);

	CreateBone(m_AiScene->mRootNode);
	m_PmxIkConstraints.clear();
	if (ModelImportUtils::LowerExtension(ModelImportUtils::FromUtf8(fileName)) == ".pmx")
	{
		LoadPmxIkData(fileName);
	}

	const filesystem::path modelPath = ModelImportUtils::FromUtf8(fileName);
	const string dirPath = ModelImportUtils::ToUtf8(modelPath.parent_path());

	XMFLOAT3 minPos = { FLT_MAX, FLT_MAX, FLT_MAX };
	XMFLOAT3 maxPos = { -FLT_MAX, -FLT_MAX, -FLT_MAX };
	bool hasVertices = false;

	for (unsigned int m = 0; m < m_AiScene->mNumMeshes; m++)
	{
		aiMesh* mesh = m_AiScene->mMeshes[m];
		m_Meshes[m].TextureIndex = ResolveMeshTextureIndex(mesh, fileName, dirPath);
		m_Meshes[m].MaterialIndex = static_cast<int>(mesh->mMaterialIndex);
		m_Meshes[m].MeshName = mesh->mName.C_Str();

		aiColor3D diffuse(1.0f, 1.0f, 1.0f);
		float opacity = 1.0f;
		aiString materialName;
		if (mesh->mMaterialIndex < m_AiScene->mNumMaterials)
		{
			auto* material = m_AiScene->mMaterials[mesh->mMaterialIndex];
			material->Get(AI_MATKEY_NAME, materialName);
			material->Get(AI_MATKEY_COLOR_DIFFUSE, diffuse);
			material->Get(AI_MATKEY_OPACITY, opacity);
		}
		const float materialPartId = MaterialPartResolver::ResolveMaterialPartId(m_AiScene, mesh);
		m_Meshes[m].MaterialName = materialName.C_Str();
		m_Meshes[m].MaterialPartId = materialPartId;
		m_Meshes[m].DefaultToonOutlineEnabled = materialPartId != 3.0f;
		const XMFLOAT4 meshDiffuse(diffuse.r, diffuse.g, diffuse.b, materialPartId);

		m_GpuSkinVertices[m].resize(mesh->mNumVertices);
		for (unsigned int v = 0; v < mesh->mNumVertices; v++)
		{
			GpuSkinVertex& gv = m_GpuSkinVertices[m][v];
			gv.Position = XMFLOAT3(mesh->mVertices[v].x, mesh->mVertices[v].y, mesh->mVertices[v].z);
			gv.Normal = mesh->HasNormals()
				? XMFLOAT3(mesh->mNormals[v].x, mesh->mNormals[v].y, mesh->mNormals[v].z)
				: XMFLOAT3(0.0f, 1.0f, 0.0f);

			minPos.x = min(minPos.x, gv.Position.x);
			minPos.y = min(minPos.y, gv.Position.y);
			minPos.z = min(minPos.z, gv.Position.z);
			maxPos.x = max(maxPos.x, gv.Position.x);
			maxPos.y = max(maxPos.y, gv.Position.y);
			maxPos.z = max(maxPos.z, gv.Position.z);
			hasVertices = true;

			const auto texCoords = mesh->mTextureCoords[0];
			gv.TexCoord = texCoords ? XMFLOAT2(texCoords[v].x, texCoords[v].y) : XMFLOAT2(0.0f, 0.0f);
			gv.Diffuse = meshDiffuse;
			for (int i = 0; i < m_kMAX_BONE_INFLUENCES; ++i)
			{
				gv.BoneIndices[i] = 0;
				gv.BoneWeights[i] = 0.0f;
			}
		}

		m_DeformVertex[m].resize(mesh->mNumVertices);
		for (unsigned int v = 0; v < mesh->mNumVertices; v++)
		{
			auto& deform = m_DeformVertex[m][v];
			deform.Position = mesh->mVertices[v];
			deform.Normal = mesh->HasNormals() ? mesh->mNormals[v] : aiVector3D(0.0f, 1.0f, 0.0f);
			deform.BoneNum = 0;
			for (int i = 0; i < m_kMAX_BONE_INFLUENCES; ++i)
			{
				deform.BoneName[i].clear();
				deform.BoneWeight[i] = 0.0f;
			}
		}

		for (unsigned int b = 0; b < mesh->mNumBones; b++)
		{
			aiBone* bone = mesh->mBones[b];
			const string boneName = bone->mName.C_Str();

			auto boneIt = m_Bone.find(boneName);
			if (boneIt == m_Bone.end())
			{
				uint32_t idx = (uint32_t)m_BoneNames.size();
				m_BoneNames.push_back(boneName);
				m_BoneIndexMap[boneName] = idx;

				const aiMatrix4x4 identity = MakeAiIdentityMatrix();
				Bone fallbackBone{};
				fallbackBone.Matrix = identity;
				fallbackBone.BindLocalMatrix = identity;
				fallbackBone.AnimationMatrix = fallbackBone.BindLocalMatrix;
				fallbackBone.OffsetMatrix = identity;
				boneIt = m_Bone.emplace(boneName, fallbackBone).first;
			}

			boneIt->second.OffsetMatrix = bone->mOffsetMatrix;

			auto it = m_BoneIndexMap.find(boneName);
			uint32_t boneIdx = (it != m_BoneIndexMap.end()) ? it->second : 0;

			for (unsigned int w = 0; w < bone->mNumWeights; w++)
			{
				aiVertexWeight weight = bone->mWeights[w];
				int num = m_DeformVertex[m][weight.mVertexId].BoneNum;
				if (num < m_kMAX_BONE_INFLUENCES)
				{
					m_DeformVertex[m][weight.mVertexId].BoneWeight[num] = weight.mWeight;
					m_DeformVertex[m][weight.mVertexId].BoneName[num] = boneName;
					m_DeformVertex[m][weight.mVertexId].BoneNum++;

					m_GpuSkinVertices[m][weight.mVertexId].BoneIndices[num] = boneIdx;
					m_GpuSkinVertices[m][weight.mVertexId].BoneWeights[num] = weight.mWeight;
				}
			}
		}

		for (unsigned int v = 0; v < mesh->mNumVertices; ++v)
		{
			NormalizeBoneInfluences(m_GpuSkinVertices[m][v], m_DeformVertex[m][v]);
		}

		{
			vector<unsigned int> indices(mesh->mNumFaces * 3);
			for (unsigned int f = 0; f < mesh->mNumFaces; f++)
			{
				const aiFace* face = &mesh->mFaces[f];
				indices[f * 3 + 0] = face->mIndices[0];
				indices[f * 3 + 1] = face->mIndices[1];
				indices[f * 3 + 2] = face->mIndices[2];
			}
			const UINT indexBufferSize = sizeof(unsigned int) * (UINT)indices.size();

			D3D12_RESOURCE_DESC ibDesc = CD3DX12_RESOURCE_DESC::Buffer(indexBufferSize);
			CD3DX12_HEAP_PROPERTIES heapProps(D3D12_HEAP_TYPE_DEFAULT);
			HRESULT hr = m_pDevice->CreateCommittedResource(&heapProps,
				D3D12_HEAP_FLAG_NONE, &ibDesc, D3D12_RESOURCE_STATE_COMMON, nullptr, IID_PPV_ARGS(&m_Meshes[m].IndexBuffer));
			if (FAILED(hr))
			{
				Debug::Log("ERROR: Failed to create DEFAULT index buffer for animated mesh\n");
				return false;
			}

			UINT64 uploadBufferSize = 0;
			m_pDevice->GetCopyableFootprints(&ibDesc, 0, 1, 0, nullptr, nullptr, nullptr, &uploadBufferSize);
			ComPtr<ID3D12Resource> uploadBuffer = TextureManager::AcquireUploadBuffer(m_pDevice, uploadBufferSize);
			if (!uploadBuffer)
			{
				Debug::Log("ERROR: Failed to acquire upload buffer for animated mesh indices\n");
				return false;
			}

			ComPtr<ID3D12CommandAllocator> cmdAlloc;
			ComPtr<ID3D12GraphicsCommandList> cmdList;
			const bool batchMode = TextureManager::IsBatchLoading();
			if (batchMode)
			{
				cmdList = TextureManager::GetBatchCommandList();
				if (!cmdList)
				{
					TextureManager::ReleaseUploadBuffer(uploadBuffer, uploadBufferSize);
					Debug::Log("ERROR: Batch command list is not initialized (anim index)\n");
					return false;
				}
			}
			else
			{
				hr = m_pDevice->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, IID_PPV_ARGS(&cmdAlloc));
				if (FAILED(hr))
				{
					TextureManager::ReleaseUploadBuffer(uploadBuffer, uploadBufferSize);
					Debug::Log("ERROR: CreateCommandAllocator failed (anim index)\n");
					return false;
				}
				hr = m_pDevice->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, cmdAlloc.Get(), nullptr, IID_PPV_ARGS(&cmdList));
				if (FAILED(hr))
				{
					TextureManager::ReleaseUploadBuffer(uploadBuffer, uploadBufferSize);
					Debug::Log("ERROR: CreateCommandList failed (anim index)\n");
					return false;
				}
			}

			auto toCopyDest = CD3DX12_RESOURCE_BARRIER::Transition(m_Meshes[m].IndexBuffer.Get(),
				D3D12_RESOURCE_STATE_COMMON, D3D12_RESOURCE_STATE_COPY_DEST);
			cmdList->ResourceBarrier(1, &toCopyDest);

			D3D12_SUBRESOURCE_DATA ibData {};
			ibData.pData = indices.data();
			ibData.RowPitch = indexBufferSize;
			ibData.SlicePitch = ibData.RowPitch;

			UpdateSubresources(cmdList.Get(), m_Meshes[m].IndexBuffer.Get(), uploadBuffer.Get(), 0, 0, 1, &ibData);

			auto barrier = CD3DX12_RESOURCE_BARRIER::Transition(m_Meshes[m].IndexBuffer.Get(),
				D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_INDEX_BUFFER);
			cmdList->ResourceBarrier(1, &barrier);

			if (!batchMode)
			{
				if (!TextureManager::ExecuteCommandListAndSync(cmdList.Get()))
				{
					TextureManager::ReleaseUploadBuffer(uploadBuffer, uploadBufferSize);
					Debug::Log("ERROR: Failed to execute and sync command list (anim index)\n");
					return false;
				}
			}

			TextureManager::ReleaseUploadBuffer(uploadBuffer, uploadBufferSize, batchMode);

			m_Meshes[m].IndexBufferView.BufferLocation = m_Meshes[m].IndexBuffer->GetGPUVirtualAddress();
			m_Meshes[m].IndexBufferView.Format = DXGI_FORMAT_R32_UINT;
			m_Meshes[m].IndexBufferView.SizeInBytes = indexBufferSize;
			m_Meshes[m].IndexCount = (UINT)indices.size();

			for (int mode = 0; mode < ToonOutlineBuilder::kModeCount; ++mode)
			{
				vector<unsigned int> teoIndices;
				ToonOutlineBuilder::BuildTeoMesh(
					m_GpuSkinVertices[m],
					indices,
					m_TeoGpuSkinVerticesByMode[m][mode],
					teoIndices,
					static_cast<ToonOutlineBuilder::Mode>(mode));
				if (m_TeoGpuSkinVerticesByMode[m][mode].empty() || teoIndices.empty())
				{
					continue;
				}

				const UINT teoIndexBufferSize = sizeof(unsigned int) * (UINT)teoIndices.size();
				D3D12_RESOURCE_DESC teoIbDesc = CD3DX12_RESOURCE_DESC::Buffer(teoIndexBufferSize);
				HRESULT teoHr = m_pDevice->CreateCommittedResource(&heapProps,
					D3D12_HEAP_FLAG_NONE, &teoIbDesc, D3D12_RESOURCE_STATE_COMMON, nullptr, IID_PPV_ARGS(&m_Meshes[m].TeoIndexBuffers[mode]));
				if (FAILED(teoHr))
				{
					Debug::Log("ERROR: Failed to create DEFAULT TEO index buffer for animated mesh\n");
					return false;
				}

				UINT64 teoUploadBufferSize = 0;
				m_pDevice->GetCopyableFootprints(&teoIbDesc, 0, 1, 0, nullptr, nullptr, nullptr, &teoUploadBufferSize);
				ComPtr<ID3D12Resource> teoUploadBuffer = TextureManager::AcquireUploadBuffer(m_pDevice, teoUploadBufferSize);
				if (!teoUploadBuffer)
				{
					Debug::Log("ERROR: Failed to acquire upload buffer for animated TEO mesh indices\n");
					return false;
				}

				ComPtr<ID3D12CommandAllocator> teoCmdAlloc;
				ComPtr<ID3D12GraphicsCommandList> teoCmdList;
				const bool teoBatchMode = TextureManager::IsBatchLoading();
				if (teoBatchMode)
				{
					teoCmdList = TextureManager::GetBatchCommandList();
					if (!teoCmdList)
					{
						TextureManager::ReleaseUploadBuffer(teoUploadBuffer, teoUploadBufferSize);
						Debug::Log("ERROR: Batch command list is not initialized (anim TEO index)\n");
						return false;
					}
				}
				else
				{
					teoHr = m_pDevice->CreateCommandAllocator(D3D12_COMMAND_LIST_TYPE_DIRECT, IID_PPV_ARGS(&teoCmdAlloc));
					if (FAILED(teoHr))
					{
						TextureManager::ReleaseUploadBuffer(teoUploadBuffer, teoUploadBufferSize);
						Debug::Log("ERROR: CreateCommandAllocator failed (anim TEO index)\n");
						return false;
					}
					teoHr = m_pDevice->CreateCommandList(0, D3D12_COMMAND_LIST_TYPE_DIRECT, teoCmdAlloc.Get(), nullptr, IID_PPV_ARGS(&teoCmdList));
					if (FAILED(teoHr))
					{
						TextureManager::ReleaseUploadBuffer(teoUploadBuffer, teoUploadBufferSize);
						Debug::Log("ERROR: CreateCommandList failed (anim TEO index)\n");
						return false;
					}
				}

				auto teoToCopyDest = CD3DX12_RESOURCE_BARRIER::Transition(m_Meshes[m].TeoIndexBuffers[mode].Get(),
					D3D12_RESOURCE_STATE_COMMON, D3D12_RESOURCE_STATE_COPY_DEST);
				teoCmdList->ResourceBarrier(1, &teoToCopyDest);

				D3D12_SUBRESOURCE_DATA teoIbData {};
				teoIbData.pData = teoIndices.data();
				teoIbData.RowPitch = teoIndexBufferSize;
				teoIbData.SlicePitch = teoIbData.RowPitch;
				UpdateSubresources(teoCmdList.Get(), m_Meshes[m].TeoIndexBuffers[mode].Get(), teoUploadBuffer.Get(), 0, 0, 1, &teoIbData);

				auto teoBarrier = CD3DX12_RESOURCE_BARRIER::Transition(m_Meshes[m].TeoIndexBuffers[mode].Get(),
					D3D12_RESOURCE_STATE_COPY_DEST, D3D12_RESOURCE_STATE_INDEX_BUFFER);
				teoCmdList->ResourceBarrier(1, &teoBarrier);

				if (!teoBatchMode)
				{
					if (!TextureManager::ExecuteCommandListAndSync(teoCmdList.Get()))
					{
						TextureManager::ReleaseUploadBuffer(teoUploadBuffer, teoUploadBufferSize);
						Debug::Log("ERROR: Failed to execute and sync command list (anim TEO index)\n");
						return false;
					}
				}

				TextureManager::ReleaseUploadBuffer(teoUploadBuffer, teoUploadBufferSize, teoBatchMode);
				m_Meshes[m].TeoIndexBufferViews[mode].BufferLocation = m_Meshes[m].TeoIndexBuffers[mode]->GetGPUVirtualAddress();
				m_Meshes[m].TeoIndexBufferViews[mode].Format = DXGI_FORMAT_R32_UINT;
				m_Meshes[m].TeoIndexBufferViews[mode].SizeInBytes = teoIndexBufferSize;
				m_Meshes[m].TeoIndexCounts[mode] = (UINT)teoIndices.size();
				m_Meshes[m].TeoVertexCounts[mode] = (UINT)m_TeoGpuSkinVerticesByMode[m][mode].size();

				if (mode == static_cast<int>(ToonOutlineBuilder::Mode::Balanced))
				{
					m_TeoGpuSkinVertices[m] = m_TeoGpuSkinVerticesByMode[m][mode];
					m_Meshes[m].TeoIndexBuffer = m_Meshes[m].TeoIndexBuffers[mode];
					m_Meshes[m].TeoIndexBufferView = m_Meshes[m].TeoIndexBufferViews[mode];
					m_Meshes[m].TeoIndexCount = m_Meshes[m].TeoIndexCounts[mode];
					m_Meshes[m].TeoVertexCount = m_Meshes[m].TeoVertexCounts[mode];
				}
			}
		}

		m_Meshes[m].VertexCount = mesh->mNumVertices;
		m_BaseGpuSkinVertices[m] = m_GpuSkinVertices[m];
	}

	BuildPmxVertexMeshMap();

	if (hasVertices)
	{
		m_AabbCenter.x = (minPos.x + maxPos.x) * 0.5f;
		m_AabbCenter.y = (minPos.y + maxPos.y) * 0.5f;
		m_AabbCenter.z = (minPos.z + maxPos.z) * 0.5f;
		m_AabbExtents.x = (maxPos.x - minPos.x) * 0.5f;
		m_AabbExtents.y = (maxPos.y - minPos.y) * 0.5f;
		m_AabbExtents.z = (maxPos.z - minPos.z) * 0.5f;
	}

	if (!CreateGpuSkinningBuffers(device))
	{
		Debug::Log("ERROR: Failed to create GPU skinning buffers for model: %s\n", fileName);
		return false;
	}

	UpdateBindPoseBoneMatrix(m_AiScene->mRootNode, MakeAiIdentityMatrix());
	WriteBoneMatricesToBuffer();

	return true;
}

bool AnimationModelResource::LoadAnimation(const char* fileName, const char* name)
{
	const filesystem::path animPath = ModelImportUtils::FromUtf8(fileName);
	if (!filesystem::exists(animPath))
	{
		Debug::Log("ERROR: Animation file not found: %s\n", fileName);
		return false;
	}

	if (ModelImportUtils::LowerExtension(animPath) == ".vmd")
	{
		return LoadVmdAnimation(fileName, name);
	}

	const aiScene* anim = ModelImportUtils::ImportScene(fileName, aiProcess_ConvertToLeftHanded);
	if (!anim)
	{
		Debug::Log("ERROR: Failed to load animation: %s (%s)\n", fileName, aiGetErrorString());
		return false;
	}

	if (!anim->HasAnimations())
	{
		Debug::Log("ERROR: Animation file has no animation tracks: %s (meshes=%u, materials=%u)\n",
			fileName, anim->mNumMeshes, anim->mNumMaterials);
		aiReleaseImport(anim);
		return false;
	}

	const aiAnimation* firstAnimation = anim->mAnimations[0];
	Debug::Log("Animation loaded: %s as '%s' (animations=%u, channels=%u, duration=%.3f, ticksPerSecond=%.3f)\n",
		fileName,
		name ? name : "",
		anim->mNumAnimations,
		firstAnimation ? firstAnimation->mNumChannels : 0,
		firstAnimation ? firstAnimation->mDuration : 0.0,
		firstAnimation ? firstAnimation->mTicksPerSecond : 0.0);

	const string animationName = name ? name : "";
	m_Animation[animationName] = anim;
	m_VmdAnimations.erase(animationName);
	return true;
}

bool AnimationModelResource::LoadVmdAnimation(const char* fileName, const char* name)
{
	const filesystem::path animPath = ModelImportUtils::FromUtf8(fileName);
	ifstream stream(animPath, ios::binary);
	if (!stream)
	{
		Debug::Log("ERROR: Failed to open VMD animation: %s\n", fileName);
		return false;
	}

	array<char, 30> header{};
	array<char, 20> modelName{};
	if (!ReadBinaryArray(stream, header) || !ReadBinaryArray(stream, modelName))
	{
		Debug::Log("ERROR: VMD header is too short: %s\n", fileName);
		return false;
	}

	const string headerText = DecodeAsciiFixedString(header.data(), header.size());
	if (headerText.rfind("Vocaloid Motion Data", 0) != 0)
	{
		Debug::Log("ERROR: Invalid VMD header: %s (header='%s')\n", fileName, headerText.c_str());
		return false;
	}

	VmdAnimation animation{};
	animation.ModelName = DecodeShiftJisFixedString(modelName.data(), modelName.size());
	if (!ReadBinary(stream, animation.MotionCount))
	{
		Debug::Log("ERROR: VMD motion count is missing: %s\n", fileName);
		return false;
	}

	for (uint32_t i = 0; i < animation.MotionCount; ++i)
	{
		array<char, 15> boneNameBytes{};
		uint32_t frame = 0;
		float px = 0.0f;
		float py = 0.0f;
		float pz = 0.0f;
		float qx = 0.0f;
		float qy = 0.0f;
		float qz = 0.0f;
		float qw = 1.0f;
		array<char, 64> interpolation{};

		if (!ReadBinaryArray(stream, boneNameBytes) ||
			!ReadBinary(stream, frame) ||
			!ReadBinary(stream, px) ||
			!ReadBinary(stream, py) ||
			!ReadBinary(stream, pz) ||
			!ReadBinary(stream, qx) ||
			!ReadBinary(stream, qy) ||
			!ReadBinary(stream, qz) ||
			!ReadBinary(stream, qw) ||
			!ReadBinaryArray(stream, interpolation))
		{
			Debug::Log("ERROR: VMD motion data is truncated: %s (motion=%u/%u)\n",
				fileName, i, animation.MotionCount);
			return false;
		}

		const string boneName = DecodeShiftJisFixedString(boneNameBytes.data(), boneNameBytes.size());
		if (boneName.empty())
		{
			continue;
		}

		aiVector3D position = ConvertVmdPositionToAssimpLeftHanded(aiVector3D(px, py, pz));
		aiQuaternion rotation = ConvertVmdRotationToAssimpLeftHanded(aiQuaternion(qw, qx, qy, qz));

		VmdKeyframe keyframe{};
		keyframe.Frame = frame;
		keyframe.Position = position;
		keyframe.Rotation = rotation;
		keyframe.InterpolationP1 = XMFLOAT2(
			NormalizeVmdInterpolationByte(static_cast<unsigned char>(interpolation[3])),
			NormalizeVmdInterpolationByte(static_cast<unsigned char>(interpolation[7])));
		keyframe.InterpolationP2 = XMFLOAT2(
			NormalizeVmdInterpolationByte(static_cast<unsigned char>(interpolation[11])),
			NormalizeVmdInterpolationByte(static_cast<unsigned char>(interpolation[15])));
		animation.BoneTracks[boneName].push_back(keyframe);
		animation.MaxFrame = max(animation.MaxFrame, frame);
	}

	if (!ReadOptionalSectionCount(stream, animation.MorphCount, "morph", fileName))
	{
		return false;
	}
	for (uint32_t i = 0; i < animation.MorphCount; ++i)
	{
		array<char, 15> morphNameBytes{};
		uint32_t frame = 0;
		float weight = 0.0f;
		if (!ReadBinaryArray(stream, morphNameBytes) ||
			!ReadBinary(stream, frame) ||
			!ReadBinary(stream, weight))
		{
			Debug::Log("ERROR: VMD morph data is truncated: %s (morph=%u/%u)\n",
				fileName, i, animation.MorphCount);
			return false;
		}

		const string morphName = DecodeShiftJisFixedString(morphNameBytes.data(), morphNameBytes.size());
		if (!morphName.empty())
		{
			animation.MorphTracks[morphName].push_back({ frame, weight });
			animation.MaxFrame = max(animation.MaxFrame, frame);
		}
	}

	if (!ReadOptionalSectionCount(stream, animation.CameraCount, "camera", fileName) ||
		!SkipBinaryBytes(stream, static_cast<uint64_t>(animation.CameraCount) * 61u, "camera", fileName))
	{
		return false;
	}

	if (!ReadOptionalSectionCount(stream, animation.LightCount, "light", fileName) ||
		!SkipBinaryBytes(stream, static_cast<uint64_t>(animation.LightCount) * 28u, "light", fileName))
	{
		return false;
	}

	if (!ReadOptionalSectionCount(stream, animation.ShadowCount, "shadow", fileName) ||
		!SkipBinaryBytes(stream, static_cast<uint64_t>(animation.ShadowCount) * 9u, "shadow", fileName))
	{
		return false;
	}

	if (!ReadOptionalSectionCount(stream, animation.IkCount, "IK", fileName))
	{
		return false;
	}
	for (uint32_t i = 0; i < animation.IkCount; ++i)
	{
		uint32_t frame = 0;
		unsigned char show = 0;
		uint32_t ikInfoCount = 0;
		if (!ReadBinary(stream, frame) ||
			!ReadBinary(stream, show) ||
			!ReadBinary(stream, ikInfoCount))
		{
			Debug::Log("ERROR: VMD IK data is truncated: %s (ik=%u/%u)\n",
				fileName, i, animation.IkCount);
			return false;
		}

		for (uint32_t info = 0; info < ikInfoCount; ++info)
		{
			array<char, 20> ikNameBytes{};
			unsigned char enable = 0;
			if (!ReadBinaryArray(stream, ikNameBytes) || !ReadBinary(stream, enable))
			{
				Debug::Log("ERROR: VMD IK info is truncated: %s (ik=%u/%u, info=%u/%u)\n",
					fileName, i, animation.IkCount, info, ikInfoCount);
				return false;
			}

			const string ikName = DecodeShiftJisFixedString(ikNameBytes.data(), ikNameBytes.size());
			if (!ikName.empty())
			{
				animation.IkTracks[ikName].push_back({ frame, enable != 0 });
				animation.MaxFrame = max(animation.MaxFrame, frame);
			}
		}
	}

	for (auto& pair : animation.BoneTracks)
	{
		vector<VmdKeyframe>& keys = pair.second;
		sort(keys.begin(), keys.end(), [](const VmdKeyframe& a, const VmdKeyframe& b)
			{
				return a.Frame < b.Frame;
			});

		vector<VmdKeyframe> uniqueKeys;
		uniqueKeys.reserve(keys.size());
		for (const VmdKeyframe& key : keys)
		{
			if (!uniqueKeys.empty() && uniqueKeys.back().Frame == key.Frame)
			{
				uniqueKeys.back() = key;
			}
			else
			{
				uniqueKeys.push_back(key);
			}
		}
		keys.swap(uniqueKeys);
	}

	for (auto& pair : animation.MorphTracks)
	{
		vector<VmdScalarKeyframe>& keys = pair.second;
		sort(keys.begin(), keys.end(), [](const VmdScalarKeyframe& a, const VmdScalarKeyframe& b)
			{
				return a.Frame < b.Frame;
			});

		vector<VmdScalarKeyframe> uniqueKeys;
		uniqueKeys.reserve(keys.size());
		for (const VmdScalarKeyframe& key : keys)
		{
			if (!uniqueKeys.empty() && uniqueKeys.back().Frame == key.Frame)
			{
				uniqueKeys.back() = key;
			}
			else
			{
				uniqueKeys.push_back(key);
			}
		}
		keys.swap(uniqueKeys);
	}

	for (auto& pair : animation.IkTracks)
	{
		vector<VmdIkKeyframe>& keys = pair.second;
		sort(keys.begin(), keys.end(), [](const VmdIkKeyframe& a, const VmdIkKeyframe& b)
			{
				return a.Frame < b.Frame;
			});

		vector<VmdIkKeyframe> uniqueKeys;
		uniqueKeys.reserve(keys.size());
		for (const VmdIkKeyframe& key : keys)
		{
			if (!uniqueKeys.empty() && uniqueKeys.back().Frame == key.Frame)
			{
				uniqueKeys.back() = key;
			}
			else
			{
				uniqueKeys.push_back(key);
			}
		}
		keys.swap(uniqueKeys);
	}

	size_t matchedTrackCount = 0;
	size_t matchedKeyCount = 0;
	for (const auto& pair : animation.BoneTracks)
	{
		if (m_Bone.find(pair.first) != m_Bone.end())
		{
			++matchedTrackCount;
			matchedKeyCount += pair.second.size();
		}
	}

	if (animation.BoneTracks.empty())
	{
		Debug::Log("ERROR: VMD has no bone motion tracks: %s (motions=%u)\n", fileName, animation.MotionCount);
		return false;
	}

	const string animationName = name ? name : "";
	m_VmdAnimations[animationName] = std::move(animation);
	m_Animation.erase(animationName);



	const VmdAnimation& loaded = m_VmdAnimations[animationName];
	Debug::Log("VMD animation loaded: %s as '%s' (model='%s', motions=%u, boneTracks=%zu, matchedTracks=%zu, matchedKeys=%zu, morphs=%u, morphTracks=%zu, cameras=%u, lights=%u, shadows=%u, ikFrames=%u, ikTracks=%zu, maxFrame=%u)\n",
		fileName,
		animationName.c_str(),
		loaded.ModelName.c_str(),
		loaded.MotionCount,
		loaded.BoneTracks.size(),
		matchedTrackCount,
		matchedKeyCount,
		loaded.MorphCount,
		loaded.MorphTracks.size(),
		loaded.CameraCount,
		loaded.LightCount,
		loaded.ShadowCount,
		loaded.IkCount,
		loaded.IkTracks.size(),
		loaded.MaxFrame);

	if (matchedTrackCount == 0)
	{
		Debug::Log("WARNING: VMD loaded but no bone names matched this model: %s\n", fileName);
	}
	return true;
}

bool AnimationModelResource::LoadPmxIkData(const char* fileName)
{
	const filesystem::path pmxPath = ModelImportUtils::FromUtf8(fileName);
	ifstream stream(pmxPath, ios::binary | ios::ate);
	if (!stream)
	{
		Debug::Log("WARNING: Failed to open PMX for IK metadata: %s\n", fileName);
		return false;
	}

	const streamsize fileSize = stream.tellg();
	if (fileSize <= 0)
	{
		Debug::Log("WARNING: PMX file is empty: %s\n", fileName);
		return false;
	}

	vector<uint8_t> bytes(static_cast<size_t>(fileSize));
	stream.seekg(0, ios::beg);
	if (!stream.read(reinterpret_cast<char*>(bytes.data()), fileSize))
	{
		Debug::Log("WARNING: Failed to read PMX for IK metadata: %s\n", fileName);
		return false;
	}

	struct PmxReader
	{
		const vector<uint8_t>& Bytes;
		size_t Pos = 0;
		uint8_t Encoding = 1;
		uint8_t AdditionalUvCount = 0;
		uint8_t VertexIndexSize = 4;
		uint8_t TextureIndexSize = 4;
		uint8_t MaterialIndexSize = 4;
		uint8_t BoneIndexSize = 4;
		uint8_t MorphIndexSize = 4;
		uint8_t RigidBodyIndexSize = 4;

		bool CanRead(size_t byteCount) const
		{
			return Pos <= Bytes.size() && byteCount <= Bytes.size() - Pos;
		}

		bool ReadBytes(void* outValue, size_t byteCount)
		{
			if (!CanRead(byteCount))
			{
				return false;
			}
			memcpy(outValue, Bytes.data() + Pos, byteCount);
			Pos += byteCount;
			return true;
		}

		bool Read(uint8_t& value) { return ReadBytes(&value, sizeof(value)); }
		bool Read(int8_t& value) { return ReadBytes(&value, sizeof(value)); }
		bool Read(uint16_t& value) { return ReadBytes(&value, sizeof(value)); }
		bool Read(int16_t& value) { return ReadBytes(&value, sizeof(value)); }
		bool Read(uint32_t& value) { return ReadBytes(&value, sizeof(value)); }
		bool Read(int32_t& value) { return ReadBytes(&value, sizeof(value)); }
		bool Read(float& value) { return ReadBytes(&value, sizeof(value)); }

		bool Skip(size_t byteCount)
		{
			if (!CanRead(byteCount))
			{
				return false;
			}
			Pos += byteCount;
			return true;
		}

		bool ReadIndex(uint8_t indexSize, int32_t& value)
		{
			if (indexSize == 1)
			{
				uint8_t raw = 0;
				if (!Read(raw)) return false;
				value = (raw == 0xff) ? -1 : static_cast<int32_t>(raw);
				return true;
			}
			if (indexSize == 2)
			{
				uint16_t raw = 0;
				if (!Read(raw)) return false;
				value = (raw == 0xffff) ? -1 : static_cast<int32_t>(raw);
				return true;
			}
			return Read(value);
		}

		bool ReadUnsignedIndex(uint8_t indexSize, uint32_t& value)
		{
			if (indexSize == 1)
			{
				uint8_t v = 0;
				if (!Read(v)) return false;
				value = v;
				return true;
			}
			if (indexSize == 2)
			{
				uint16_t v = 0;
				if (!Read(v)) return false;
				value = static_cast<uint32_t>(v);
				return true;
			}
			int32_t signedValue = 0;
			if (!Read(signedValue) || signedValue < 0)
			{
				return false;
			}
			value = static_cast<uint32_t>(signedValue);
			return true;
		}

		bool SkipIndex(uint8_t indexSize)
		{
			return Skip(indexSize);
		}

		bool ReadText(string& text)
		{
			int32_t byteLength = 0;
			if (!Read(byteLength) || byteLength < 0 || !CanRead(static_cast<size_t>(byteLength)))
			{
				return false;
			}
			if (byteLength == 0)
			{
				text.clear();
				return true;
			}

			if (Encoding == 0)
			{
				const int wideLength = byteLength / 2;
				wstring wideText(static_cast<size_t>(wideLength), L'\0');
				memcpy(wideText.data(), Bytes.data() + Pos, static_cast<size_t>(wideLength) * sizeof(wchar_t));
				Pos += static_cast<size_t>(byteLength);

				const int utf8Length = WideCharToMultiByte(CP_UTF8, 0, wideText.data(), wideLength, nullptr, 0, nullptr, nullptr);
				if (utf8Length <= 0)
				{
					text.clear();
					return true;
				}
				text.assign(static_cast<size_t>(utf8Length), '\0');
				WideCharToMultiByte(CP_UTF8, 0, wideText.data(), wideLength, text.data(), utf8Length, nullptr, nullptr);
				return true;
			}

			text.assign(reinterpret_cast<const char*>(Bytes.data() + Pos), static_cast<size_t>(byteLength));
			Pos += static_cast<size_t>(byteLength);
			return true;
		}
	};

	struct RawIkLink
	{
		int32_t BoneIndex = -1;
		bool HasLimit = false;
		aiVector3D LimitMin{};
		aiVector3D LimitMax{};
	};

	struct RawBone
	{
		string Name{};
		uint16_t Flags = 0;
		int32_t DeformDepth = 0;
		int32_t AppendBoneIndex = -1;
		float AppendWeight = 0.0f;
		int32_t IkTargetIndex = -1;
		uint32_t IkIterationCount = 0;
		float IkLimitAngle = 0.0f;
		vector<RawIkLink> IkLinks{};
	};

	auto readFloat3 = [](PmxReader& reader, aiVector3D& outValue)
		{
			return reader.Read(outValue.x) && reader.Read(outValue.y) && reader.Read(outValue.z);
		};
	auto readFloat4 = [](PmxReader& reader, XMFLOAT4& outValue)
		{
			return reader.Read(outValue.x) && reader.Read(outValue.y) &&
				reader.Read(outValue.z) && reader.Read(outValue.w);
		};

	PmxReader reader{ bytes };
	array<char, 4> magic{};
	if (!reader.CanRead(4))
	{
		return false;
	}
	memcpy(magic.data(), bytes.data(), 4);
	reader.Pos = 4;
	if (string(magic.data(), magic.size()) != "PMX ")
	{
		Debug::Log("WARNING: PMX IK metadata skipped because header is invalid: %s\n", fileName);
		return false;
	}

	float version = 0.0f;
	uint8_t configSize = 0;
	if (!reader.Read(version) || !reader.Read(configSize) || !reader.CanRead(configSize))
	{
		Debug::Log("WARNING: PMX IK metadata header is truncated: %s\n", fileName);
		return false;
	}
	if (configSize < 8)
	{
		Debug::Log("WARNING: PMX IK metadata config is too short: %s\n", fileName);
		return false;
	}

	reader.Read(reader.Encoding);
	reader.Read(reader.AdditionalUvCount);
	reader.Read(reader.VertexIndexSize);
	reader.Read(reader.TextureIndexSize);
	reader.Read(reader.MaterialIndexSize);
	reader.Read(reader.BoneIndexSize);
	reader.Read(reader.MorphIndexSize);
	reader.Read(reader.RigidBodyIndexSize);
	if (configSize > 8)
	{
		reader.Skip(configSize - 8);
	}

	string ignoredText;
	if (!reader.ReadText(ignoredText) || !reader.ReadText(ignoredText) ||
		!reader.ReadText(ignoredText) || !reader.ReadText(ignoredText))
	{
		Debug::Log("WARNING: PMX IK metadata model text is truncated: %s\n", fileName);
		return false;
	}

	int32_t vertexCount = 0;
	if (!reader.Read(vertexCount) || vertexCount < 0)
	{
		Debug::Log("WARNING: PMX IK metadata vertex count is invalid: %s\n", fileName);
		return false;
	}
	m_PmxBaseVertices.clear();
	m_PmxBaseNormals.clear();
	m_PmxBaseTexCoords.clear();
	m_PmxBaseVertices.resize(static_cast<size_t>(vertexCount));
	m_PmxBaseNormals.resize(static_cast<size_t>(vertexCount));
	m_PmxBaseTexCoords.resize(static_cast<size_t>(vertexCount));
	for (int32_t i = 0; i < vertexCount; ++i)
	{
		aiVector3D position{};
		aiVector3D normal{};
		XMFLOAT2 uv{};
		if (!readFloat3(reader, position) ||
			!readFloat3(reader, normal) ||
			!reader.Read(uv.x) ||
			!reader.Read(uv.y) ||
			!reader.Skip(static_cast<size_t>(reader.AdditionalUvCount) * 16))
		{
			Debug::Log("WARNING: PMX IK metadata vertex data is truncated: %s\n", fileName);
			return false;
		}
		m_PmxBaseVertices[static_cast<size_t>(i)] = ConvertVmdPositionToAssimpLeftHanded(position);
		m_PmxBaseNormals[static_cast<size_t>(i)] = ConvertVmdPositionToAssimpLeftHanded(normal);
		m_PmxBaseTexCoords[static_cast<size_t>(i)] = uv;

		uint8_t deformType = 0;
		if (!reader.Read(deformType))
		{
			return false;
		}
		switch (deformType)
		{
		case 0:
			if (!reader.SkipIndex(reader.BoneIndexSize)) return false;
			break;
		case 1:
			if (!reader.Skip(static_cast<size_t>(reader.BoneIndexSize) * 2 + 4)) return false;
			break;
		case 2:
			if (!reader.Skip(static_cast<size_t>(reader.BoneIndexSize) * 4 + 16)) return false;
			break;
		case 3:
			if (!reader.Skip(static_cast<size_t>(reader.BoneIndexSize) * 2 + 40)) return false;
			break;
		case 4:
			if (!reader.Skip(static_cast<size_t>(reader.BoneIndexSize) * 4 + 16)) return false;
			break;
		default:
			Debug::Log("WARNING: PMX IK metadata unknown deform type %u: %s\n", deformType, fileName);
			return false;
		}
		if (!reader.Skip(4))
		{
			return false;
		}
	}

	int32_t indexCount = 0;
	if (!reader.Read(indexCount) || indexCount < 0 ||
		!reader.Skip(static_cast<size_t>(indexCount) * reader.VertexIndexSize))
	{
		Debug::Log("WARNING: PMX IK metadata index data is truncated: %s\n", fileName);
		return false;
	}

	int32_t textureCount = 0;
	if (!reader.Read(textureCount) || textureCount < 0)
	{
		return false;
	}
	for (int32_t i = 0; i < textureCount; ++i)
	{
		if (!reader.ReadText(ignoredText)) return false;
	}

	int32_t materialCount = 0;
	if (!reader.Read(materialCount) || materialCount < 0)
	{
		return false;
	}
	for (int32_t i = 0; i < materialCount; ++i)
	{
		if (!reader.ReadText(ignoredText) || !reader.ReadText(ignoredText) ||
			!reader.Skip(65) ||
			!reader.SkipIndex(reader.TextureIndexSize) ||
			!reader.SkipIndex(reader.TextureIndexSize))
		{
			return false;
		}

		uint8_t sphereMode = 0;
		uint8_t toonFlag = 0;
		if (!reader.Read(sphereMode) || !reader.Read(toonFlag))
		{
			return false;
		}
		if (toonFlag == 0)
		{
			if (!reader.SkipIndex(reader.TextureIndexSize)) return false;
		}
		else
		{
			if (!reader.Skip(1)) return false;
		}
		if (!reader.ReadText(ignoredText) || !reader.Skip(4))
		{
			return false;
		}
	}

	int32_t boneCount = 0;
	if (!reader.Read(boneCount) || boneCount < 0)
	{
		Debug::Log("WARNING: PMX IK metadata bone count is invalid: %s\n", fileName);
		return false;
	}

	vector<RawBone> rawBones(static_cast<size_t>(boneCount));
	for (int32_t i = 0; i < boneCount; ++i)
	{
		RawBone& rawBone = rawBones[static_cast<size_t>(i)];
		string englishName;
		aiVector3D ignoredVec{};
		int32_t ignoredIndex = -1;
		if (!reader.ReadText(rawBone.Name) ||
			!reader.ReadText(englishName) ||
			!readFloat3(reader, ignoredVec) ||
			!reader.ReadIndex(reader.BoneIndexSize, ignoredIndex) ||
			!reader.Read(rawBone.DeformDepth) ||
			!reader.Read(rawBone.Flags))
		{
			Debug::Log("WARNING: PMX IK metadata bone data is truncated: %s\n", fileName);
			return false;
		}

		if ((rawBone.Flags & 0x0001) != 0)
		{
			if (!reader.ReadIndex(reader.BoneIndexSize, ignoredIndex)) return false;
		}
		else if (!reader.Skip(12))
		{
			return false;
		}

		if ((rawBone.Flags & 0x0100) != 0 || (rawBone.Flags & 0x0200) != 0)
		{
			if (!reader.ReadIndex(reader.BoneIndexSize, rawBone.AppendBoneIndex) ||
				!reader.Read(rawBone.AppendWeight))
			{
				return false;
			}
		}
		if ((rawBone.Flags & 0x0400) != 0 && !reader.Skip(12)) return false;
		if ((rawBone.Flags & 0x0800) != 0 && !reader.Skip(24)) return false;
		if ((rawBone.Flags & 0x2000) != 0 && !reader.Skip(4)) return false;

		if ((rawBone.Flags & 0x0020) != 0)
		{
			int32_t linkCount = 0;
			if (!reader.ReadIndex(reader.BoneIndexSize, rawBone.IkTargetIndex) ||
				!reader.Read(rawBone.IkIterationCount) ||
				!reader.Read(rawBone.IkLimitAngle) ||
				!reader.Read(linkCount) ||
				linkCount < 0)
			{
				return false;
			}

			rawBone.IkLinks.resize(static_cast<size_t>(linkCount));
			for (int32_t link = 0; link < linkCount; ++link)
			{
				RawIkLink& rawLink = rawBone.IkLinks[static_cast<size_t>(link)];
				uint8_t hasLimit = 0;
				if (!reader.ReadIndex(reader.BoneIndexSize, rawLink.BoneIndex) || !reader.Read(hasLimit))
				{
					return false;
				}
				rawLink.HasLimit = hasLimit != 0;
				if (rawLink.HasLimit)
				{
					if (!readFloat3(reader, rawLink.LimitMin) || !readFloat3(reader, rawLink.LimitMax))
					{
						return false;
					}
				}
			}
		}
	}

	int32_t morphCount = 0;
	if (!reader.Read(morphCount) || morphCount < 0)
	{
		Debug::Log("WARNING: PMX morph metadata count is invalid: %s\n", fileName);
		return false;
	}

	m_PmxMorphs.clear();
	m_PmxMorphIndexMap.clear();
	m_PmxMorphs.resize(static_cast<size_t>(morphCount));
	for (int32_t i = 0; i < morphCount; ++i)
	{
		PmxMorph& morph = m_PmxMorphs[static_cast<size_t>(i)];
		string englishName;
		uint8_t panel = 0;
		int32_t offsetCount = 0;
		if (!reader.ReadText(morph.Name) ||
			!reader.ReadText(englishName) ||
			!reader.Read(panel) ||
			!reader.Read(morph.Type) ||
			!reader.Read(offsetCount) ||
			offsetCount < 0)
		{
			Debug::Log("WARNING: PMX morph metadata is truncated: %s\n", fileName);
			return false;
		}
		if (!morph.Name.empty())
		{
			m_PmxMorphIndexMap[morph.Name] = static_cast<uint32_t>(i);
		}

		for (int32_t offset = 0; offset < offsetCount; ++offset)
		{
			switch (morph.Type)
			{
			case 0:
			{
				int32_t morphIndex = -1;
				float weight = 0.0f;
				if (!reader.ReadIndex(reader.MorphIndexSize, morphIndex) || !reader.Read(weight))
				{
					return false;
				}
				if (morphIndex >= 0)
				{
					morph.GroupOffsets.push_back({ static_cast<uint32_t>(morphIndex), weight });
				}
				break;
			}
			case 1:
			{
				uint32_t vertexIndex = 0;
				aiVector3D position{};
				if (!reader.ReadUnsignedIndex(reader.VertexIndexSize, vertexIndex) ||
					!readFloat3(reader, position))
				{
					return false;
				}
				morph.PositionOffsets.push_back({ vertexIndex, ConvertVmdPositionToAssimpLeftHanded(position) });
				break;
			}
			case 2:
			{
				int32_t boneIndex = -1;
				aiVector3D position{};
				float qx = 0.0f;
				float qy = 0.0f;
				float qz = 0.0f;
				float qw = 1.0f;
				if (!reader.ReadIndex(reader.BoneIndexSize, boneIndex) ||
					!readFloat3(reader, position) ||
					!reader.Read(qx) ||
					!reader.Read(qy) ||
					!reader.Read(qz) ||
					!reader.Read(qw))
				{
					return false;
				}
				if (boneIndex >= 0 && boneIndex < boneCount)
				{
					PmxBoneMorphOffset boneOffset{};
					boneOffset.BoneName = rawBones[static_cast<size_t>(boneIndex)].Name;
					boneOffset.Position = ConvertVmdPositionToAssimpLeftHanded(position);
					boneOffset.Rotation = ConvertVmdRotationToAssimpLeftHanded(aiQuaternion(qw, qx, qy, qz));
					morph.BoneOffsets.push_back(boneOffset);
				}
				break;
			}
			case 3:
			{
				uint32_t vertexIndex = 0;
				XMFLOAT4 uv{};
				if (!reader.ReadUnsignedIndex(reader.VertexIndexSize, vertexIndex) ||
					!readFloat4(reader, uv))
				{
					return false;
				}
				morph.UvOffsets.push_back({ vertexIndex, uv });
				break;
			}
			case 4:
			case 5:
			case 6:
			case 7:
				if (!reader.SkipIndex(reader.VertexIndexSize) || !reader.Skip(16)) return false;
				break;
			case 8:
			{
				PmxMaterialMorphOffset materialOffset{};
				XMFLOAT4 ignored{};
				float ignoredFloat = 0.0f;
				if (!reader.ReadIndex(reader.MaterialIndexSize, materialOffset.MaterialIndex) ||
					!reader.Read(materialOffset.Operation) ||
					!readFloat4(reader, materialOffset.Diffuse) ||
					!reader.Skip(12) ||
					!reader.Read(ignoredFloat) ||
					!reader.Skip(12) ||
					!readFloat4(reader, ignored) ||
					!reader.Read(ignoredFloat) ||
					!readFloat4(reader, ignored) ||
					!readFloat4(reader, ignored) ||
					!readFloat4(reader, ignored))
				{
					return false;
				}
				morph.MaterialOffsets.push_back(materialOffset);
				break;
			}
				break;
			case 9:
				if (!reader.SkipIndex(reader.MorphIndexSize) || !reader.Skip(4)) return false;
				break;
			case 10:
				if (!reader.SkipIndex(reader.RigidBodyIndexSize) || !reader.Skip(25)) return false;
				break;
			default:
				Debug::Log("WARNING: PMX morph metadata unknown morph type %u: %s\n", morph.Type, fileName);
				return false;
			}
		}
	}

	m_PmxAppendConstraints.clear();
	for (int32_t i = 0; i < boneCount; ++i)
	{
		const RawBone& rawBone = rawBones[static_cast<size_t>(i)];
		if (((rawBone.Flags & 0x0100) == 0 && (rawBone.Flags & 0x0200) == 0) ||
			rawBone.AppendBoneIndex < 0 ||
			rawBone.AppendBoneIndex >= boneCount)
		{
			continue;
		}

		PmxAppendConstraint constraint{};
		constraint.BoneName = rawBone.Name;
		constraint.AppendBoneName = rawBones[static_cast<size_t>(rawBone.AppendBoneIndex)].Name;
		constraint.Weight = rawBone.AppendWeight;
		constraint.InheritRotation = (rawBone.Flags & 0x0100) != 0;
		constraint.InheritTranslation = (rawBone.Flags & 0x0200) != 0;
		constraint.Local = (rawBone.Flags & 0x0080) != 0;
		constraint.DeformDepth = rawBone.DeformDepth;
		constraint.BoneOrder = static_cast<uint32_t>(i);
		if (!constraint.BoneName.empty() && !constraint.AppendBoneName.empty())
		{
			m_PmxAppendConstraints.push_back(std::move(constraint));
		}
	}

	m_PmxIkConstraints.clear();
	for (int32_t i = 0; i < boneCount; ++i)
	{
		const RawBone& rawBone = rawBones[static_cast<size_t>(i)];
		if ((rawBone.Flags & 0x0020) == 0 ||
			rawBone.IkTargetIndex < 0 ||
			rawBone.IkTargetIndex >= boneCount)
		{
			continue;
		}

		PmxIkConstraint constraint{};
		constraint.BoneName = rawBone.Name;
		constraint.TargetBoneName = rawBones[static_cast<size_t>(rawBone.IkTargetIndex)].Name;
		constraint.IterationCount = rawBone.IkIterationCount;
		constraint.LimitAngle = rawBone.IkLimitAngle;
		constraint.DeformDepth = rawBone.DeformDepth;
		constraint.BoneOrder = static_cast<uint32_t>(i);
		for (const RawIkLink& rawLink : rawBone.IkLinks)
		{
			if (rawLink.BoneIndex < 0 || rawLink.BoneIndex >= boneCount)
			{
				continue;
			}

			PmxIkLink link{};
			link.BoneName = rawBones[static_cast<size_t>(rawLink.BoneIndex)].Name;
			link.HasLimit = rawLink.HasLimit;
			link.LimitMin = rawLink.LimitMin;
			link.LimitMax = rawLink.LimitMax;
			constraint.Links.push_back(link);
		}

		if (!constraint.BoneName.empty() && !constraint.TargetBoneName.empty() && !constraint.Links.empty())
		{
			m_PmxIkConstraints.push_back(std::move(constraint));
		}
	}

	auto comparePmxTransformOrder = [](const auto& lhs, const auto& rhs)
		{
			if (lhs.DeformDepth != rhs.DeformDepth)
			{
				return lhs.DeformDepth < rhs.DeformDepth;
			}
			return lhs.BoneOrder < rhs.BoneOrder;
		};
	sort(m_PmxAppendConstraints.begin(), m_PmxAppendConstraints.end(), comparePmxTransformOrder);
	sort(m_PmxIkConstraints.begin(), m_PmxIkConstraints.end(), comparePmxTransformOrder);

	size_t positionMorphCount = 0;
	size_t uvMorphCount = 0;
	size_t boneMorphCount = 0;
	size_t materialMorphCount = 0;
	size_t groupMorphCount = 0;
	for (const PmxMorph& morph : m_PmxMorphs)
	{
		if (!morph.PositionOffsets.empty()) ++positionMorphCount;
		if (!morph.UvOffsets.empty()) ++uvMorphCount;
		if (!morph.BoneOffsets.empty()) ++boneMorphCount;
		if (!morph.MaterialOffsets.empty()) ++materialMorphCount;
		if (!morph.GroupOffsets.empty()) ++groupMorphCount;
	}

	Debug::Log("PMX animation metadata loaded: %s (vertices=%zu, bones=%d, appendConstraints=%zu, ikConstraints=%zu, morphs=%zu, positionMorphs=%zu, uvMorphs=%zu, boneMorphs=%zu, materialMorphs=%zu, groupMorphs=%zu)\n",
		fileName, m_PmxBaseVertices.size(), boneCount, m_PmxAppendConstraints.size(), m_PmxIkConstraints.size(),
		m_PmxMorphs.size(), positionMorphCount, uvMorphCount, boneMorphCount, materialMorphCount, groupMorphCount);
	return true;
}

bool AnimationModelResource::TryLoadEmbeddedTextureByIndex(const aiString& texPath, const char* modelName, int& outTexIndex) const
{
	if (texPath.length == 0 || texPath.data[0] != '*')
	{
		return false;
	}

	const int texIdx = atoi(&texPath.data[1]);
	if (texIdx < 0 || texIdx >= static_cast<int>(m_AiScene->mNumTextures))
	{
		return false;
	}

	aiTexture* aiTex = m_AiScene->mTextures[texIdx];
	string uniqueName = string(modelName) + "_" + texPath.C_Str();
	outTexIndex = TextureManager::LoadTextureFromMemory(
		uniqueName.c_str(),
		reinterpret_cast<const uint8_t*>(aiTex->pcData),
		aiTex->mWidth);
	return true;
}

bool AnimationModelResource::TryLoadEmbeddedTextureByName(const aiString& texPath, const char* modelName, int& outTexIndex) const
{
	for (unsigned int i = 0; i < m_AiScene->mNumTextures; ++i)
	{
		if (strcmp(m_AiScene->mTextures[i]->mFilename.C_Str(), texPath.C_Str()) != 0)
		{
			continue;
		}

		aiTexture* aiTex = m_AiScene->mTextures[i];
		string uniqueName = string(modelName) + "_" + texPath.C_Str();
		outTexIndex = TextureManager::LoadTextureFromMemory(
			uniqueName.c_str(),
			reinterpret_cast<const uint8_t*>(aiTex->pcData),
			aiTex->mWidth);
		return true;
	}
	return false;
}

int AnimationModelResource::ResolveMeshTextureIndex(const aiMesh* mesh, const char* fileName, const string& dirPath) const
{
	int textureIndex = TextureManager::GetDefaultTextureIndex();
	if (mesh->mMaterialIndex >= m_AiScene->mNumMaterials)
	{
		return textureIndex;
	}

	aiMaterial* material = m_AiScene->mMaterials[mesh->mMaterialIndex];
	aiString texPath;
	const bool hasTexture =
		(material->GetTexture(aiTextureType_DIFFUSE, 0, &texPath) == AI_SUCCESS) ||
		(material->GetTexture(aiTextureType_BASE_COLOR, 0, &texPath) == AI_SUCCESS);
	if (!hasTexture)
	{
		return textureIndex;
	}

	if (TryLoadEmbeddedTextureByIndex(texPath, fileName, textureIndex) ||
		TryLoadEmbeddedTextureByName(texPath, fileName, textureIndex))
	{
		return textureIndex;
	}

	auto toLower = [](string value)
		{
			return MaterialPartResolver::ToLowerString(value);
		};
	auto isSupportedTextureExtension = [&](const filesystem::path& path)
		{
			const string ext = toLower(path.extension().string());
			return ext == ".png" || ext == ".jpg" || ext == ".jpeg" ||
				ext == ".bmp" || ext == ".tga" || ext == ".tif" || ext == ".tiff" ||
				ext == ".dds" || ext == ".sph" || ext == ".spa";
		};
	auto pushCandidate = [](vector<filesystem::path>& paths, const filesystem::path& path)
		{
			if (find(paths.begin(), paths.end(), path) == paths.end())
			{
				paths.push_back(path);
			}
		};

	filesystem::path texFilePath = ModelImportUtils::FromUtf8(texPath.C_Str());
	vector<filesystem::path> candidates;
	if (texFilePath.extension() != ".tga" && texFilePath.extension() != ".TGA")
	{
		filesystem::path tgaPath = texFilePath;
		tgaPath.replace_extension(".tga");
		pushCandidate(candidates, ModelImportUtils::FromUtf8(dirPath.c_str()) / tgaPath);
		pushCandidate(candidates, ModelImportUtils::FromUtf8(dirPath.c_str()) / tgaPath.filename());
	}
	if (isSupportedTextureExtension(texFilePath))
	{
		if (texFilePath.is_absolute())
		{
			pushCandidate(candidates, texFilePath);
		}
		pushCandidate(candidates, ModelImportUtils::FromUtf8(dirPath.c_str()) / texFilePath);
		pushCandidate(candidates, ModelImportUtils::FromUtf8(dirPath.c_str()) / texFilePath.filename());
	}

	for (const auto& candidate : candidates)
	{
		if (filesystem::exists(candidate))
		{
			return TextureManager::LoadTexture(candidate);
		}
	}

	Debug::Log("WARNING: Animation model texture not found: %s\n", texPath.C_Str());
	return textureIndex;
}

aiNodeAnim* AnimationModelResource::FindNodeAnimChannel(aiAnimation* animation, const string& boneName) const
{
	if (!animation)
	{
		return nullptr;
	}

	for (unsigned int c = 0; c < animation->mNumChannels; ++c)
	{
		if (animation->mChannels[c]->mNodeName == aiString(boneName))
		{
			return animation->mChannels[c];
		}
	}
	return nullptr;
}

void AnimationModelResource::SampleNodeAnimation(aiAnimation* animation, aiNodeAnim* channel, float timeSeconds,
	aiQuaternion& outRotation, aiVector3D& outPosition, aiVector3D& outScale) const
{
	if (!animation || !channel)
	{
		return;
	}

	const float ticksPerSecond = (animation->mTicksPerSecond != 0) ? static_cast<float>(animation->mTicksPerSecond) : 25.0f;
	const float duration = static_cast<float>(animation->mDuration);
	const float t = duration > 0.0f ? fmod(max(0.0f, timeSeconds) * ticksPerSecond, duration) : 0.0f;

	auto sampleVector = [t](const aiVectorKey* keys, unsigned int count, aiVector3D& output)
		{
			if (!keys || count == 0) return;
			if (count == 1 || t <= static_cast<float>(keys[0].mTime))
			{
				output = keys[0].mValue;
				return;
			}
			for (unsigned int i = 0; i + 1 < count; ++i)
			{
				const float start = static_cast<float>(keys[i].mTime);
				const float end = static_cast<float>(keys[i + 1].mTime);
				if (t <= end)
				{
					const float factor = end > start ? clamp((t - start) / (end - start), 0.0f, 1.0f) : 0.0f;
					output = keys[i].mValue * (1.0f - factor) + keys[i + 1].mValue * factor;
					return;
				}
			}
			output = keys[count - 1].mValue;
		};

	auto sampleRotation = [t](const aiQuatKey* keys, unsigned int count, aiQuaternion& output)
		{
			if (!keys || count == 0) return;
			if (count == 1 || t <= static_cast<float>(keys[0].mTime))
			{
				output = keys[0].mValue;
				return;
			}
			for (unsigned int i = 0; i + 1 < count; ++i)
			{
				const float start = static_cast<float>(keys[i].mTime);
				const float end = static_cast<float>(keys[i + 1].mTime);
				if (t <= end)
				{
					const float factor = end > start ? clamp((t - start) / (end - start), 0.0f, 1.0f) : 0.0f;
					aiQuaternion::Interpolate(output, keys[i].mValue, keys[i + 1].mValue, factor);
					output.Normalize();
					return;
				}
			}
			output = keys[count - 1].mValue;
		};

	sampleRotation(channel->mRotationKeys, channel->mNumRotationKeys, outRotation);
	sampleVector(channel->mPositionKeys, channel->mNumPositionKeys, outPosition);
	sampleVector(channel->mScalingKeys, channel->mNumScalingKeys, outScale);
}

bool AnimationModelResource::CreateGpuSkinningBuffers(ID3D12Device* device)
{
	UINT numMeshes = (UINT)m_Meshes.size();

	{
		UINT boneBufferSize = sizeof(XMFLOAT4X4) * m_kMAX_BONES;
		auto heapProps = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_UPLOAD);
		auto resDesc = CD3DX12_RESOURCE_DESC::Buffer(boneBufferSize);
		HRESULT hr = device->CreateCommittedResource(&heapProps, D3D12_HEAP_FLAG_NONE,
			&resDesc, D3D12_RESOURCE_STATE_GENERIC_READ, nullptr, IID_PPV_ARGS(&m_BoneBuffer));
		if (FAILED(hr)) return false;

		CD3DX12_RANGE readRange(0, 0);
		hr = m_BoneBuffer->Map(0, &readRange, &m_pBoneBufferMapped);
		if (FAILED(hr))
		{
			Debug::Log("ERROR: Failed to map bone buffer\n");
			m_pBoneBufferMapped = nullptr;
			return false;
		}

		if (m_pBoneBufferMapped)
		{
			vector<XMFLOAT4X4> identityBones(m_kMAX_BONES);
			XMFLOAT4X4 identity;
			XMStoreFloat4x4(&identity, XMMatrixIdentity());
			for (auto& mtx : identityBones)
			{
				mtx = identity;
			}
			memcpy(m_pBoneBufferMapped, identityBones.data(), sizeof(XMFLOAT4X4) * m_kMAX_BONES);
		}
	}

	{
		D3D12_DESCRIPTOR_HEAP_DESC heapDesc {};
		heapDesc.NumDescriptors = numMeshes * m_kSKINNING_DESCRIPTORS_PER_MESH;
		heapDesc.Type = D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV;
		heapDesc.Flags = D3D12_DESCRIPTOR_HEAP_FLAG_SHADER_VISIBLE;
		HRESULT hr = device->CreateDescriptorHeap(&heapDesc, IID_PPV_ARGS(&m_SkinningDescHeap));
		if (FAILED(hr)) return false;
	}

	UINT descSize = device->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);

	for (UINT m = 0; m < numMeshes; m++)
	{
		UINT vertexCount = m_Meshes[m].VertexCount;
		const UINT descriptorBase = m * m_kSKINNING_DESCRIPTORS_PER_MESH;

		{
			UINT bufSize = sizeof(GpuSkinVertex) * vertexCount;
			auto heapProps = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_UPLOAD);
			auto resDesc = CD3DX12_RESOURCE_DESC::Buffer(bufSize);
			HRESULT hr = device->CreateCommittedResource(&heapProps, D3D12_HEAP_FLAG_NONE,
				&resDesc, D3D12_RESOURCE_STATE_GENERIC_READ, nullptr, IID_PPV_ARGS(&m_Meshes[m].InputVertexBuffer));
			if (FAILED(hr)) return false;

			UINT8* pDest = nullptr;
			CD3DX12_RANGE readRange(0, 0);
			hr = m_Meshes[m].InputVertexBuffer->Map(0, &readRange, reinterpret_cast<void**>(&pDest));
			if (FAILED(hr) || !pDest)
			{
				Debug::Log("ERROR: Failed to map input vertex buffer\n");
				return false;
			}
			memcpy(pDest, m_GpuSkinVertices[m].data(), bufSize);
			m_Meshes[m].InputVertexBuffer->Unmap(0, nullptr);

			D3D12_SHADER_RESOURCE_VIEW_DESC srvDesc {};
			srvDesc.ViewDimension = D3D12_SRV_DIMENSION_BUFFER;
			srvDesc.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
			srvDesc.Buffer.NumElements = vertexCount;
			srvDesc.Buffer.StructureByteStride = sizeof(GpuSkinVertex);
			srvDesc.Format = DXGI_FORMAT_UNKNOWN;
			m_Meshes[m].SrvInputVertexIndex = descriptorBase + m_kINPUT_VERTEX_SRV_OFFSET;
			CD3DX12_CPU_DESCRIPTOR_HANDLE srvHandle(m_SkinningDescHeap->GetCPUDescriptorHandleForHeapStart(),
				m_Meshes[m].SrvInputVertexIndex, descSize);
			device->CreateShaderResourceView(m_Meshes[m].InputVertexBuffer.Get(), &srvDesc, srvHandle);
		}

		{
			D3D12_SHADER_RESOURCE_VIEW_DESC srvDesc {};
			srvDesc.ViewDimension = D3D12_SRV_DIMENSION_BUFFER;
			srvDesc.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
			srvDesc.Buffer.NumElements = m_kMAX_BONES;
			srvDesc.Buffer.StructureByteStride = sizeof(XMFLOAT4X4);
			srvDesc.Format = DXGI_FORMAT_UNKNOWN;
			CD3DX12_CPU_DESCRIPTOR_HANDLE srvHandle(m_SkinningDescHeap->GetCPUDescriptorHandleForHeapStart(),
				descriptorBase + m_kBONE_SRV_OFFSET, descSize);
			device->CreateShaderResourceView(m_BoneBuffer.Get(), &srvDesc, srvHandle);
		}

		{
			UINT bufSize = sizeof(ModelVertex) * vertexCount;
			auto heapProps = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_DEFAULT);
			auto resDesc = CD3DX12_RESOURCE_DESC::Buffer(bufSize, D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS);
			HRESULT hr = device->CreateCommittedResource(&heapProps, D3D12_HEAP_FLAG_NONE,
				&resDesc, D3D12_RESOURCE_STATE_COMMON, nullptr, IID_PPV_ARGS(&m_Meshes[m].VertexBuffer));
			if (FAILED(hr)) return false;

			D3D12_UNORDERED_ACCESS_VIEW_DESC uavDesc {};
			uavDesc.ViewDimension = D3D12_UAV_DIMENSION_BUFFER;
			uavDesc.Buffer.NumElements = vertexCount;
			uavDesc.Buffer.StructureByteStride = sizeof(ModelVertex);
			uavDesc.Format = DXGI_FORMAT_UNKNOWN;
			m_Meshes[m].UavOutputVertexIndex = descriptorBase + m_kOUTPUT_VERTEX_UAV_OFFSET;
			CD3DX12_CPU_DESCRIPTOR_HANDLE uavHandle(m_SkinningDescHeap->GetCPUDescriptorHandleForHeapStart(),
				m_Meshes[m].UavOutputVertexIndex, descSize);
			device->CreateUnorderedAccessView(m_Meshes[m].VertexBuffer.Get(), nullptr, &uavDesc, uavHandle);

			m_Meshes[m].VertexBufferView.BufferLocation = m_Meshes[m].VertexBuffer->GetGPUVirtualAddress();
			m_Meshes[m].VertexBufferView.SizeInBytes = bufSize;
			m_Meshes[m].VertexBufferView.StrideInBytes = sizeof(ModelVertex);
		}

		for (int mode = 0; mode < ToonOutlineBuilder::kModeCount; ++mode)
		{
			const UINT teoVertexCount = m_Meshes[m].TeoVertexCounts[mode];
			if (teoVertexCount == 0 || m_TeoGpuSkinVerticesByMode[m][mode].empty())
			{
				continue;
			}

			{
				UINT bufSize = sizeof(GpuSkinVertex) * teoVertexCount;
				auto heapProps = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_UPLOAD);
				auto resDesc = CD3DX12_RESOURCE_DESC::Buffer(bufSize);
				HRESULT hr = device->CreateCommittedResource(&heapProps, D3D12_HEAP_FLAG_NONE,
					&resDesc, D3D12_RESOURCE_STATE_GENERIC_READ, nullptr, IID_PPV_ARGS(&m_Meshes[m].TeoInputVertexBuffers[mode]));
				if (FAILED(hr)) return false;

				UINT8* pDest = nullptr;
				CD3DX12_RANGE readRange(0, 0);
				hr = m_Meshes[m].TeoInputVertexBuffers[mode]->Map(0, &readRange, reinterpret_cast<void**>(&pDest));
				if (FAILED(hr) || !pDest)
				{
					Debug::Log("ERROR: Failed to map TEO input vertex buffer\n");
					return false;
				}
				memcpy(pDest, m_TeoGpuSkinVerticesByMode[m][mode].data(), bufSize);
				m_Meshes[m].TeoInputVertexBuffers[mode]->Unmap(0, nullptr);

				D3D12_SHADER_RESOURCE_VIEW_DESC srvDesc {};
				srvDesc.ViewDimension = D3D12_SRV_DIMENSION_BUFFER;
				srvDesc.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;
				srvDesc.Buffer.NumElements = teoVertexCount;
				srvDesc.Buffer.StructureByteStride = sizeof(GpuSkinVertex);
				srvDesc.Format = DXGI_FORMAT_UNKNOWN;
				m_Meshes[m].SrvTeoInputVertexIndices[mode] = descriptorBase + m_kTEO_DESCRIPTOR_OFFSET + (mode * 2);
				CD3DX12_CPU_DESCRIPTOR_HANDLE srvHandle(m_SkinningDescHeap->GetCPUDescriptorHandleForHeapStart(),
					m_Meshes[m].SrvTeoInputVertexIndices[mode], descSize);
				device->CreateShaderResourceView(m_Meshes[m].TeoInputVertexBuffers[mode].Get(), &srvDesc, srvHandle);
			}

			{
				UINT bufSize = sizeof(ModelVertex) * teoVertexCount;
				auto heapProps = CD3DX12_HEAP_PROPERTIES(D3D12_HEAP_TYPE_DEFAULT);
				auto resDesc = CD3DX12_RESOURCE_DESC::Buffer(bufSize, D3D12_RESOURCE_FLAG_ALLOW_UNORDERED_ACCESS);
				HRESULT hr = device->CreateCommittedResource(&heapProps, D3D12_HEAP_FLAG_NONE,
					&resDesc, D3D12_RESOURCE_STATE_COMMON, nullptr, IID_PPV_ARGS(&m_Meshes[m].TeoVertexBuffers[mode]));
				if (FAILED(hr)) return false;

				D3D12_UNORDERED_ACCESS_VIEW_DESC uavDesc {};
				uavDesc.ViewDimension = D3D12_UAV_DIMENSION_BUFFER;
				uavDesc.Buffer.NumElements = teoVertexCount;
				uavDesc.Buffer.StructureByteStride = sizeof(ModelVertex);
				uavDesc.Format = DXGI_FORMAT_UNKNOWN;
				m_Meshes[m].UavTeoOutputVertexIndices[mode] = descriptorBase + m_kTEO_DESCRIPTOR_OFFSET + (mode * 2) + 1;
				CD3DX12_CPU_DESCRIPTOR_HANDLE uavHandle(m_SkinningDescHeap->GetCPUDescriptorHandleForHeapStart(),
					m_Meshes[m].UavTeoOutputVertexIndices[mode], descSize);
				device->CreateUnorderedAccessView(m_Meshes[m].TeoVertexBuffers[mode].Get(), nullptr, &uavDesc, uavHandle);

				m_Meshes[m].TeoVertexBufferViews[mode].BufferLocation = m_Meshes[m].TeoVertexBuffers[mode]->GetGPUVirtualAddress();
				m_Meshes[m].TeoVertexBufferViews[mode].SizeInBytes = bufSize;
				m_Meshes[m].TeoVertexBufferViews[mode].StrideInBytes = sizeof(ModelVertex);

				if (mode == static_cast<int>(ToonOutlineBuilder::Mode::Balanced))
				{
					m_Meshes[m].TeoInputVertexBuffer = m_Meshes[m].TeoInputVertexBuffers[mode];
					m_Meshes[m].TeoVertexBuffer = m_Meshes[m].TeoVertexBuffers[mode];
					m_Meshes[m].TeoVertexBufferView = m_Meshes[m].TeoVertexBufferViews[mode];
					m_Meshes[m].SrvTeoInputVertexIndex = m_Meshes[m].SrvTeoInputVertexIndices[mode];
					m_Meshes[m].UavTeoOutputVertexIndex = m_Meshes[m].UavTeoOutputVertexIndices[mode];
				}
			}
		}
	}
	return true;
}

aiAnimation* AnimationModelResource::GetAnimation(const string& name)
{
	auto it = m_Animation.find(name);
	if (it != m_Animation.end() && it->second->HasAnimations())
	{
		return it->second->mAnimations[0];
	}
	if (m_AiScene && m_AiScene->HasAnimations())
	{
		if (name == "default" || name.empty())
		{
			return m_AiScene->mAnimations[0];
		}
		for (unsigned int i = 0; i < m_AiScene->mNumAnimations; ++i)
		{
			if (name == m_AiScene->mAnimations[i]->mName.C_Str())
			{
				return m_AiScene->mAnimations[i];
			}
		}
		if (m_AiScene->mNumAnimations == 1)
		{
			return m_AiScene->mAnimations[0];
		}
	}
	return nullptr;
}

bool AnimationModelResource::ApplyMeshShadingOverridePartIds(const vector<int>& overridePartIds)
{
	bool success = true;
	for (UINT meshIndex = 0; meshIndex < (UINT)m_Meshes.size(); ++meshIndex)
	{
		MeshData& meshData = m_Meshes[meshIndex];
		const float targetPartId =
			(meshIndex < overridePartIds.size() && overridePartIds[meshIndex] >= 0)
			? static_cast<float>(overridePartIds[meshIndex])
			: meshData.MaterialPartId;

		for (GpuSkinVertex& vertex : m_GpuSkinVertices[meshIndex])
		{
			vertex.Diffuse.w = targetPartId;
		}
		if (meshIndex < m_BaseGpuSkinVertices.size())
		{
			for (GpuSkinVertex& vertex : m_BaseGpuSkinVertices[meshIndex])
			{
				vertex.Diffuse.w = targetPartId;
			}
		}
		if (meshData.InputVertexBuffer && !m_GpuSkinVertices[meshIndex].empty())
		{
			UINT8* pDest = nullptr;
			CD3DX12_RANGE readRange(0, 0);
			HRESULT hr = meshData.InputVertexBuffer->Map(0, &readRange, reinterpret_cast<void**>(&pDest));
			if (SUCCEEDED(hr) && pDest)
			{
				memcpy(pDest, m_GpuSkinVertices[meshIndex].data(),
					sizeof(GpuSkinVertex) * m_GpuSkinVertices[meshIndex].size());
				meshData.InputVertexBuffer->Unmap(0, nullptr);
			}
			else
			{
				Debug::Log("ERROR: Failed to update animated mesh shading input buffer\n");
				success = false;
			}
		}

		for (int mode = 0; mode < ToonOutlineBuilder::kModeCount; ++mode)
		{
			auto& teoVertices = m_TeoGpuSkinVerticesByMode[meshIndex][mode];
			for (GpuSkinVertex& vertex : teoVertices)
			{
				vertex.Diffuse.w = targetPartId;
			}
			if (meshData.TeoInputVertexBuffers[mode] && !teoVertices.empty())
			{
				UINT8* pDest = nullptr;
				CD3DX12_RANGE readRange(0, 0);
				HRESULT hr = meshData.TeoInputVertexBuffers[mode]->Map(0, &readRange, reinterpret_cast<void**>(&pDest));
				if (SUCCEEDED(hr) && pDest)
				{
					memcpy(pDest, teoVertices.data(), sizeof(GpuSkinVertex) * teoVertices.size());
					meshData.TeoInputVertexBuffers[mode]->Unmap(0, nullptr);
				}
				else
				{
					Debug::Log("ERROR: Failed to update animated mesh shading TEO input buffer\n");
					success = false;
				}
			}
			if (mode == static_cast<int>(ToonOutlineBuilder::Mode::Balanced))
			{
				m_TeoGpuSkinVertices[meshIndex] = teoVertices;
			}
		}
	}
	return success;
}

void AnimationModelResource::UpdateBoneMatrix(aiNode* node, aiMatrix4x4 matrix)
{
	auto it = m_Bone.find(node->mName.C_Str());
	if (it == m_Bone.end())
	{
		for (unsigned int n = 0; n < node->mNumChildren; n++)
		{
			UpdateBoneMatrix(node->mChildren[n], matrix);
		}
		return;
	}

	Bone* bonePtr = &it->second;
	aiMatrix4x4 worldMatrix = matrix * bonePtr->AnimationMatrix;
	bonePtr->Matrix = worldMatrix * bonePtr->OffsetMatrix;

	for (unsigned int n = 0; n < node->mNumChildren; n++)
	{
		UpdateBoneMatrix(node->mChildren[n], worldMatrix);
	}
}

void AnimationModelResource::UpdateBindPoseBoneMatrix(aiNode* node, aiMatrix4x4 matrix)
{
	if (!node)
	{
		return;
	}

	aiMatrix4x4 worldMatrix = matrix * node->mTransformation;

	auto it = m_Bone.find(node->mName.C_Str());
	if (it != m_Bone.end())
	{
		Bone* bonePtr = &it->second;
		bonePtr->BindLocalMatrix = node->mTransformation;
		bonePtr->AnimationMatrix = node->mTransformation;
		bonePtr->Matrix = worldMatrix * bonePtr->OffsetMatrix;
	}

	for (unsigned int n = 0; n < node->mNumChildren; n++)
	{
		UpdateBindPoseBoneMatrix(node->mChildren[n], worldMatrix);
	}
}

void AnimationModelResource::WriteBoneMatricesToBuffer()
{
	if (!m_pBoneBufferMapped)
	{
		return;
	}

	if (m_BoneMatricesScratch.size() != m_kMAX_BONES)
	{
		m_BoneMatricesScratch.resize(m_kMAX_BONES);
	}

	XMFLOAT4X4 identity;
	XMStoreFloat4x4(&identity, XMMatrixIdentity());
	for (auto& mtx : m_BoneMatricesScratch)
	{
		mtx = identity;
	}

	for (const auto& kv : m_BoneIndexMap)
	{
		uint32_t idx = kv.second;
		if (idx >= m_kMAX_BONES) continue;
		const aiMatrix4x4& src = m_Bone.at(kv.first).Matrix;
		XMFLOAT4X4& dst = m_BoneMatricesScratch[idx];
		dst._11 = src.a1; dst._12 = src.a2; dst._13 = src.a3; dst._14 = src.a4;
		dst._21 = src.b1; dst._22 = src.b2; dst._23 = src.b3; dst._24 = src.b4;
		dst._31 = src.c1; dst._32 = src.c2; dst._33 = src.c3; dst._34 = src.c4;
		dst._41 = src.d1; dst._42 = src.d2; dst._43 = src.d3; dst._44 = src.d4;
	}

	UINT copySize = sizeof(XMFLOAT4X4) * m_kMAX_BONES;
	memcpy(m_pBoneBufferMapped, m_BoneMatricesScratch.data(), copySize);
}

void AnimationModelResource::BuildPmxVertexMeshMap()
{
	m_PmxVertexToMeshVertices.clear();
	if (m_PmxBaseVertices.empty() || m_GpuSkinVertices.empty())
	{
		return;
	}

	auto quantize = [](float value)
		{
			return llround(static_cast<double>(value) * 10000.0);
		};
	auto makePositionKey = [&](float x, float y, float z)
		{
			return to_string(quantize(x)) + "," + to_string(quantize(y)) + "," + to_string(quantize(z));
		};
	auto makeVertexKey = [&](const aiVector3D& position, const aiVector3D& normal, const XMFLOAT2& uv)
		{
			return makePositionKey(position.x, position.y, position.z) + "|" +
				makePositionKey(normal.x, normal.y, normal.z) + "|" +
				to_string(quantize(uv.x)) + "," + to_string(quantize(uv.y));
		};

	unordered_map<string, vector<uint32_t>> pmxVerticesByPosition;
	unordered_map<string, vector<uint32_t>> pmxVerticesByVertex;
	pmxVerticesByPosition.reserve(m_PmxBaseVertices.size());
	pmxVerticesByVertex.reserve(m_PmxBaseVertices.size());
	for (uint32_t i = 0; i < static_cast<uint32_t>(m_PmxBaseVertices.size()); ++i)
	{
		const aiVector3D& position = m_PmxBaseVertices[i];
		pmxVerticesByPosition[makePositionKey(position.x, position.y, position.z)].push_back(i);
		if (i < m_PmxBaseNormals.size() && i < m_PmxBaseTexCoords.size())
		{
			pmxVerticesByVertex[makeVertexKey(position, m_PmxBaseNormals[i], m_PmxBaseTexCoords[i])].push_back(i);
		}
	}

	m_PmxVertexToMeshVertices.resize(m_PmxBaseVertices.size());
	size_t mappedMeshVertices = 0;
	size_t preciseMappedMeshVertices = 0;
	for (uint32_t meshIndex = 0; meshIndex < static_cast<uint32_t>(m_GpuSkinVertices.size()); ++meshIndex)
	{
		const vector<GpuSkinVertex>& vertices = m_GpuSkinVertices[meshIndex];
		for (uint32_t vertexIndex = 0; vertexIndex < static_cast<uint32_t>(vertices.size()); ++vertexIndex)
		{
			const XMFLOAT3& position = vertices[vertexIndex].Position;
			const XMFLOAT3& normal = vertices[vertexIndex].Normal;
			const XMFLOAT2& uv = vertices[vertexIndex].TexCoord;

			aiVector3D aiPosition(position.x, position.y, position.z);
			aiVector3D aiNormal(normal.x, normal.y, normal.z);
			const vector<uint32_t>* matchedPmxVertices = nullptr;
			auto preciseIt = pmxVerticesByVertex.find(makeVertexKey(aiPosition, aiNormal, uv));
			if (preciseIt != pmxVerticesByVertex.end())
			{
				matchedPmxVertices = &preciseIt->second;
				++preciseMappedMeshVertices;
			}
			else
			{
				auto positionIt = pmxVerticesByPosition.find(makePositionKey(position.x, position.y, position.z));
				if (positionIt != pmxVerticesByPosition.end())
				{
					matchedPmxVertices = &positionIt->second;
				}
			}
			if (!matchedPmxVertices)
			{
				continue;
			}

			++mappedMeshVertices;
			for (uint32_t pmxVertexIndex : *matchedPmxVertices)
			{
				m_PmxVertexToMeshVertices[pmxVertexIndex].push_back({ meshIndex, vertexIndex });
			}
		}
	}

	Debug::Log("PMX morph vertex map built: pmxVertices=%zu, mappedMeshVertices=%zu, preciseMappedMeshVertices=%zu\n",
		m_PmxBaseVertices.size(), mappedMeshVertices, preciseMappedMeshVertices);
}

float AnimationModelResource::SampleVmdMorph(const VmdAnimation* animation, const string& morphName, float timeSeconds) const
{
	if (!animation)
	{
		return 0.0f;
	}

	auto trackIt = animation->MorphTracks.find(morphName);
	if (trackIt == animation->MorphTracks.end() || trackIt->second.empty())
	{
		return 0.0f;
	}

	const vector<VmdScalarKeyframe>& keys = trackIt->second;
	float currentFrame = max(0.0f, timeSeconds) * 30.0f;
	if (animation->MaxFrame > 0)
	{
		currentFrame = fmod(currentFrame, static_cast<float>(animation->MaxFrame) + 1.0f);
	}

	auto nextIt = lower_bound(keys.begin(), keys.end(), currentFrame,
		[](const VmdScalarKeyframe& key, float frame)
		{
			return static_cast<float>(key.Frame) < frame;
		});
	if (nextIt == keys.begin())
	{
		return nextIt->Value;
	}
	if (nextIt == keys.end())
	{
		return keys.back().Value;
	}

	const VmdScalarKeyframe& next = *nextIt;
	const VmdScalarKeyframe& prev = *(nextIt - 1);
	if (next.Frame == prev.Frame)
	{
		return next.Value;
	}

	const float factor = clamp(
		(currentFrame - static_cast<float>(prev.Frame)) / static_cast<float>(next.Frame - prev.Frame),
		0.0f, 1.0f);
	return prev.Value * (1.0f - factor) + next.Value * factor;
}

void AnimationModelResource::ApplyVmdMorphs(const VmdAnimation* animation, float timeSeconds)
{
	if (!animation || m_PmxMorphs.empty())
	{
		return;
	}

	const bool canApplyVertexMorphs =
		!m_PmxVertexToMeshVertices.empty() &&
		!m_BaseGpuSkinVertices.empty() &&
		m_BaseGpuSkinVertices.size() == m_GpuSkinVertices.size();

	if (canApplyVertexMorphs)
	{
		for (size_t meshIndex = 0; meshIndex < m_GpuSkinVertices.size(); ++meshIndex)
		{
			m_GpuSkinVertices[meshIndex] = m_BaseGpuSkinVertices[meshIndex];
		}
	}

	vector<aiVector3D> accumulatedOffsets(m_PmxBaseVertices.size(), aiVector3D(0.0f, 0.0f, 0.0f));
	vector<XMFLOAT2> accumulatedUvOffsets(m_PmxBaseVertices.size(), XMFLOAT2(0.0f, 0.0f));
	bool vertexBufferChanged = false;
	auto accumulateMorph = [&](auto&& self, uint32_t morphIndex, float weight, int depth) -> void
		{
			if (weight == 0.0f || morphIndex >= m_PmxMorphs.size() || depth > 8)
			{
				return;
			}

			const PmxMorph& morph = m_PmxMorphs[morphIndex];
			if (canApplyVertexMorphs)
			{
				for (const PmxPositionMorphOffset& offset : morph.PositionOffsets)
				{
					if (offset.VertexIndex >= accumulatedOffsets.size())
					{
						continue;
					}
					accumulatedOffsets[offset.VertexIndex] += offset.Position * weight;
				}

				for (const PmxUvMorphOffset& offset : morph.UvOffsets)
				{
					if (offset.VertexIndex >= accumulatedUvOffsets.size())
					{
						continue;
					}
					accumulatedUvOffsets[offset.VertexIndex].x += offset.Uv.x * weight;
					accumulatedUvOffsets[offset.VertexIndex].y += offset.Uv.y * weight;
				}

				for (const PmxMaterialMorphOffset& offset : morph.MaterialOffsets)
				{
					for (size_t meshIndex = 0; meshIndex < m_Meshes.size(); ++meshIndex)
					{
						const MeshData& meshData = m_Meshes[meshIndex];
						if (offset.MaterialIndex >= 0 && meshData.MaterialIndex != offset.MaterialIndex)
						{
							continue;
						}

						for (GpuSkinVertex& vertex : m_GpuSkinVertices[meshIndex])
						{
							if (offset.Operation == 0)
							{
								vertex.Diffuse.x *= 1.0f + (offset.Diffuse.x - 1.0f) * weight;
								vertex.Diffuse.y *= 1.0f + (offset.Diffuse.y - 1.0f) * weight;
								vertex.Diffuse.z *= 1.0f + (offset.Diffuse.z - 1.0f) * weight;
							}
							else
							{
								vertex.Diffuse.x += offset.Diffuse.x * weight;
								vertex.Diffuse.y += offset.Diffuse.y * weight;
								vertex.Diffuse.z += offset.Diffuse.z * weight;
							}
						}
						vertexBufferChanged = true;
					}
				}
			}

			for (const PmxBoneMorphOffset& offset : morph.BoneOffsets)
			{
				auto boneIt = m_Bone.find(offset.BoneName);
				if (boneIt == m_Bone.end())
				{
					continue;
				}

				aiVector3D scale(1.0f, 1.0f, 1.0f);
				aiQuaternion rotation(1.0f, 0.0f, 0.0f, 0.0f);
				aiVector3D position(0.0f, 0.0f, 0.0f);
				boneIt->second.AnimationMatrix.Decompose(scale, rotation, position);

				position += offset.Position * weight;

				aiQuaternion weightedRotation;
				aiQuaternion::Interpolate(weightedRotation,
					aiQuaternion(1.0f, 0.0f, 0.0f, 0.0f),
					offset.Rotation,
					clamp(fabsf(weight), 0.0f, 1.0f));
				weightedRotation.Normalize();
				if (weight < 0.0f)
				{
					weightedRotation.Conjugate();
				}
				rotation = rotation * weightedRotation;
				rotation.Normalize();

				boneIt->second.AnimationMatrix = aiMatrix4x4(scale, rotation, position);
			}

			for (const auto& groupOffset : morph.GroupOffsets)
			{
				self(self, groupOffset.first, weight * groupOffset.second, depth + 1);
			}
		};

	for (const auto& track : animation->MorphTracks)
	{
		auto morphIt = m_PmxMorphIndexMap.find(track.first);
		if (morphIt == m_PmxMorphIndexMap.end())
		{
			continue;
		}

		const float weight = SampleVmdMorph(animation, track.first, timeSeconds);
		if (fabsf(weight) <= 0.00001f)
		{
			continue;
		}
		accumulateMorph(accumulateMorph, morphIt->second, weight, 0);
	}

	bool anyMorphApplied = false;
	if (canApplyVertexMorphs)
	{
		anyMorphApplied = vertexBufferChanged;
		for (uint32_t pmxVertexIndex = 0; pmxVertexIndex < static_cast<uint32_t>(accumulatedOffsets.size()); ++pmxVertexIndex)
		{
			const aiVector3D& offset = accumulatedOffsets[pmxVertexIndex];
			const XMFLOAT2& uvOffset = accumulatedUvOffsets[pmxVertexIndex];
			const bool hasPositionOffset =
				fabsf(offset.x) > 0.000001f || fabsf(offset.y) > 0.000001f || fabsf(offset.z) > 0.000001f;
			const bool hasUvOffset =
				fabsf(uvOffset.x) > 0.000001f || fabsf(uvOffset.y) > 0.000001f;
			if (!hasPositionOffset && !hasUvOffset)
			{
				continue;
			}

			if (pmxVertexIndex >= m_PmxVertexToMeshVertices.size())
			{
				continue;
			}

			for (const auto& target : m_PmxVertexToMeshVertices[pmxVertexIndex])
			{
				const uint32_t meshIndex = target.first;
				const uint32_t vertexIndex = target.second;
				if (meshIndex >= m_GpuSkinVertices.size() || vertexIndex >= m_GpuSkinVertices[meshIndex].size())
				{
					continue;
				}

				GpuSkinVertex& vertex = m_GpuSkinVertices[meshIndex][vertexIndex];
				if (hasPositionOffset)
				{
					vertex.Position.x += offset.x;
					vertex.Position.y += offset.y;
					vertex.Position.z += offset.z;
				}
				if (hasUvOffset)
				{
					vertex.TexCoord.x += uvOffset.x;
					vertex.TexCoord.y += uvOffset.y;
				}
				anyMorphApplied = true;
			}
		}
	}

	if ((!anyMorphApplied && !m_HasAppliedVmdMorphs) || !canApplyVertexMorphs)
	{
		return;
	}

	for (size_t meshIndex = 0; meshIndex < m_Meshes.size(); ++meshIndex)
	{
		MeshData& meshData = m_Meshes[meshIndex];
		if (!meshData.InputVertexBuffer || m_GpuSkinVertices[meshIndex].empty())
		{
			continue;
		}

		UINT8* pDest = nullptr;
		CD3DX12_RANGE readRange(0, 0);
		HRESULT hr = meshData.InputVertexBuffer->Map(0, &readRange, reinterpret_cast<void**>(&pDest));
		if (SUCCEEDED(hr) && pDest)
		{
			memcpy(pDest, m_GpuSkinVertices[meshIndex].data(),
				sizeof(GpuSkinVertex) * m_GpuSkinVertices[meshIndex].size());
			meshData.InputVertexBuffer->Unmap(0, nullptr);
		}
	}
	m_HasAppliedVmdMorphs = anyMorphApplied;
}

void AnimationModelResource::ApplyPmxAppendTransforms()
{
	if (m_PmxAppendConstraints.empty() || !m_AiScene)
	{
		return;
	}

	auto aiToXm = [](const aiMatrix4x4& src)
		{
			return XMMatrixSet(
				src.a1, src.a2, src.a3, src.a4,
				src.b1, src.b2, src.b3, src.b4,
				src.c1, src.c2, src.c3, src.c4,
				src.d1, src.d2, src.d3, src.d4);
		};

	unordered_map<string, XMFLOAT4X4> globalMatrices;
	auto rebuildGlobals = [&]()
		{
			globalMatrices.clear();
			auto buildRecursive = [&](auto&& self, aiNode* node, XMMATRIX parentMatrix) -> void
				{
					if (!node)
					{
						return;
					}

					const string nodeName = node->mName.C_Str();
					XMMATRIX localMatrix = aiToXm(node->mTransformation);
					auto boneIt = m_Bone.find(nodeName);
					if (boneIt != m_Bone.end())
					{
						localMatrix = aiToXm(boneIt->second.AnimationMatrix);
					}

					const XMMATRIX worldMatrix = XMMatrixMultiply(parentMatrix, localMatrix);
					XMFLOAT4X4 storedWorld{};
					XMStoreFloat4x4(&storedWorld, worldMatrix);
					globalMatrices[nodeName] = storedWorld;

					for (unsigned int n = 0; n < node->mNumChildren; ++n)
					{
						self(self, node->mChildren[n], worldMatrix);
					}
				};
			buildRecursive(buildRecursive, m_AiScene->mRootNode, XMMatrixIdentity());
		};

	auto loadGlobal = [&](const string& boneName)
		{
			auto it = globalMatrices.find(boneName);
			return it != globalMatrices.end() ? XMLoadFloat4x4(&it->second) : XMMatrixIdentity();
		};

	for (int pass = 0; pass < 2; ++pass)
	{
		rebuildGlobals();
		for (const PmxAppendConstraint& constraint : m_PmxAppendConstraints)
		{
			auto boneIt = m_Bone.find(constraint.BoneName);
			auto appendIt = m_Bone.find(constraint.AppendBoneName);
			if (boneIt == m_Bone.end() || appendIt == m_Bone.end())
			{
				continue;
			}

			aiVector3D scale(1.0f, 1.0f, 1.0f);
			aiQuaternion rotation(1.0f, 0.0f, 0.0f, 0.0f);
			aiVector3D position(0.0f, 0.0f, 0.0f);
			boneIt->second.AnimationMatrix.Decompose(scale, rotation, position);

			aiVector3D appendScale(1.0f, 1.0f, 1.0f);
			aiQuaternion appendRotation(1.0f, 0.0f, 0.0f, 0.0f);
			aiVector3D appendPosition(0.0f, 0.0f, 0.0f);
			if (constraint.Local)
			{
				appendIt->second.AnimationMatrix.Decompose(appendScale, appendRotation, appendPosition);
			}
			else
			{
				XMVECTOR appendScaleVector = XMVectorSet(1.0f, 1.0f, 1.0f, 0.0f);
				XMVECTOR appendRotationVector = XMQuaternionIdentity();
				XMVECTOR appendPositionVector = XMVectorZero();
				if (XMMatrixDecompose(&appendScaleVector, &appendRotationVector, &appendPositionVector, loadGlobal(constraint.AppendBoneName)))
				{
					XMFLOAT3 storedScale{};
					XMFLOAT4 storedRotation{};
					XMFLOAT3 storedPosition{};
					XMStoreFloat3(&storedScale, appendScaleVector);
					XMStoreFloat4(&storedRotation, XMQuaternionNormalize(appendRotationVector));
					XMStoreFloat3(&storedPosition, appendPositionVector);
					appendScale = aiVector3D(storedScale.x, storedScale.y, storedScale.z);
					appendRotation = aiQuaternion(storedRotation.w, storedRotation.x, storedRotation.y, storedRotation.z);
					appendPosition = aiVector3D(storedPosition.x, storedPosition.y, storedPosition.z);
				}
			}

			if (constraint.InheritRotation)
			{
				aiQuaternion weightedRotation;
				aiQuaternion::Interpolate(weightedRotation,
					aiQuaternion(1.0f, 0.0f, 0.0f, 0.0f),
					appendRotation,
					clamp(fabsf(constraint.Weight), 0.0f, 1.0f));
				weightedRotation.Normalize();
				if (constraint.Weight < 0.0f)
				{
					weightedRotation.Conjugate();
				}
				rotation = rotation * weightedRotation;
				rotation.Normalize();
			}

			if (constraint.InheritTranslation)
			{
				position += appendPosition * constraint.Weight;
			}

			boneIt->second.AnimationMatrix = aiMatrix4x4(scale, rotation, position);
		}
	}
}

void AnimationModelResource::ApplyPmxOrderedTransforms(const VmdAnimation* animation, float timeSeconds)
{
	if (!m_AiScene || (m_PmxAppendConstraints.empty() && m_PmxIkConstraints.empty()))
	{
		return;
	}

	auto aiToXm = [](const aiMatrix4x4& src)
		{
			return XMMatrixSet(
				src.a1, src.a2, src.a3, src.a4,
				src.b1, src.b2, src.b3, src.b4,
				src.c1, src.c2, src.c3, src.c4,
				src.d1, src.d2, src.d3, src.d4);
		};

	unordered_map<string, XMFLOAT4X4> globalMatrices;
	auto rebuildGlobals = [&]()
		{
			globalMatrices.clear();
			auto buildRecursive = [&](auto&& self, aiNode* node, XMMATRIX parentMatrix) -> void
				{
					if (!node)
					{
						return;
					}

					const string nodeName = node->mName.C_Str();
					XMMATRIX localMatrix = aiToXm(node->mTransformation);
					auto boneIt = m_Bone.find(nodeName);
					if (boneIt != m_Bone.end())
					{
						localMatrix = aiToXm(boneIt->second.AnimationMatrix);
					}

					const XMMATRIX worldMatrix = XMMatrixMultiply(parentMatrix, localMatrix);
					XMFLOAT4X4 storedWorld{};
					XMStoreFloat4x4(&storedWorld, worldMatrix);
					globalMatrices[nodeName] = storedWorld;

					for (unsigned int n = 0; n < node->mNumChildren; ++n)
					{
						self(self, node->mChildren[n], worldMatrix);
					}
				};
			buildRecursive(buildRecursive, m_AiScene->mRootNode, XMMatrixIdentity());
		};

	auto loadGlobal = [&](const string& boneName)
		{
			auto it = globalMatrices.find(boneName);
			return it != globalMatrices.end() ? XMLoadFloat4x4(&it->second) : XMMatrixIdentity();
		};

	auto getTranslation = [&](const string& boneName)
		{
			auto it = globalMatrices.find(boneName);
			if (it == globalMatrices.end())
			{
				return XMVectorZero();
			}

			const XMFLOAT4X4& matrix = it->second;


			if (!logged &&
				(boneName == "�����h�j" || boneName == "������" ||
					boneName == "�E���h�j" || boneName == "�E����"))
			{
				Debug::Log(
					"========================================================================================IK matrix [%s] colTrans=(%.3f, %.3f, %.3f) rowTrans=(%.3f, %.3f, %.3f)\n",
					boneName.c_str(),
					matrix._14, matrix._24, matrix._34,
					matrix._41, matrix._42, matrix._43
				);
			}

			return XMVectorSet(matrix._41, matrix._42, matrix._43, 1.0f);
		};

	auto getParentGlobal = [&](const string& boneName)
		{
			auto parentIt = m_BoneParentMap.find(boneName);
			if (parentIt == m_BoneParentMap.end())
			{
				return XMMatrixIdentity();
			}
			return loadGlobal(parentIt->second);
		};

	auto applyIkLinkLimit = [](const PmxIkLink& link, XMVECTOR& localAxis, float& angle) -> bool
		{
			if (!link.HasLimit)
			{
				return true;
			}

			const float component[3] =
			{
				XMVectorGetX(localAxis),
				XMVectorGetY(localAxis),
				XMVectorGetZ(localAxis),
			};
			const float minLimit[3] = { link.LimitMin.x, link.LimitMin.y, link.LimitMin.z };
			const float maxLimit[3] = { link.LimitMax.x, link.LimitMax.y, link.LimitMax.z };

			float limitedComponent[3] = {};
			float maxAllowedAngle = 0.0f;
			int fallbackAxis = -1;
			float fallbackAxisLimit = 0.0f;
			for (int axis = 0; axis < 3; ++axis)
			{
				float low = minLimit[axis];
				float high = maxLimit[axis];
				if (low > high)
				{
					swap(low, high);
				}

				const float axisLimit = max(fabsf(low), fabsf(high));
				const bool allowsAxis = fabsf(high - low) > 0.00001f && axisLimit > 0.00001f;
				if (!allowsAxis)
				{
					continue;
				}

				float signedComponent = component[axis];
				const bool allowsPositive = high > 0.00001f;
				const bool allowsNegative = low < -0.00001f;
				if (allowsPositive && !allowsNegative)
				{
					signedComponent = fabsf(signedComponent);
				}
				else if (!allowsPositive && allowsNegative)
				{
					signedComponent = -fabsf(signedComponent);
				}

				limitedComponent[axis] = signedComponent;
				maxAllowedAngle = max(maxAllowedAngle, axisLimit);
				if (axisLimit > fallbackAxisLimit)
				{
					fallbackAxis = axis;
					fallbackAxisLimit = axisLimit;
				}
			}

			if (maxAllowedAngle <= 0.00001f)
			{
				return false;
			}

			XMVECTOR limitedAxis = XMVectorSet(
				limitedComponent[0],
				limitedComponent[1],
				limitedComponent[2],
				0.0f);
			if (XMVectorGetX(XMVector3LengthSq(limitedAxis)) < 0.000001f)
			{
				float fallbackComponent[3] = {};
				float low = minLimit[fallbackAxis];
				float high = maxLimit[fallbackAxis];
				if (low > high)
				{
					swap(low, high);
				}

				const bool allowsPositive = high > 0.00001f;
				const bool allowsNegative = low < -0.00001f;
				float sign = component[fallbackAxis] < 0.0f ? -1.0f : 1.0f;
				if (allowsPositive && !allowsNegative)
				{
					sign = 1.0f;
				}
				else if (!allowsPositive && allowsNegative)
				{
					sign = -1.0f;
				}
				fallbackComponent[fallbackAxis] = sign;
				limitedAxis = XMVectorSet(
					fallbackComponent[0],
					fallbackComponent[1],
					fallbackComponent[2],
					0.0f);
			}

			localAxis = XMVector3Normalize(limitedAxis);
			angle = min(angle, maxAllowedAngle);
			return true;
		};

	struct PmxAppendResult
	{
		aiQuaternion Rotation{ 1.0f, 0.0f, 0.0f, 0.0f };
		aiVector3D Translation{ 0.0f, 0.0f, 0.0f };
	};
	unordered_map<string, PmxAppendResult> appendResults;

	auto getLocalAnimationDelta = [](const Bone& bone, aiQuaternion& outRotation, aiVector3D& outTranslation)
		{
			aiVector3D baseScale(1.0f, 1.0f, 1.0f);
			aiQuaternion baseRotation(1.0f, 0.0f, 0.0f, 0.0f);
			aiVector3D basePosition(0.0f, 0.0f, 0.0f);
			bone.BindLocalMatrix.Decompose(baseScale, baseRotation, basePosition);

			aiVector3D currentScale(1.0f, 1.0f, 1.0f);
			aiQuaternion currentRotation(1.0f, 0.0f, 0.0f, 0.0f);
			aiVector3D currentPosition(0.0f, 0.0f, 0.0f);
			bone.AnimationMatrix.Decompose(currentScale, currentRotation, currentPosition);

			aiQuaternion inverseBase = baseRotation;
			inverseBase.Conjugate();
			outRotation = inverseBase * currentRotation;
			outRotation.Normalize();
			outTranslation = currentPosition - basePosition;
		};

	auto applyAppend = [&](const PmxAppendConstraint& constraint)
		{
			auto boneIt = m_Bone.find(constraint.BoneName);
			auto appendIt = m_Bone.find(constraint.AppendBoneName);
			if (boneIt == m_Bone.end() || appendIt == m_Bone.end())
			{
				return false;
			}

			aiVector3D scale(1.0f, 1.0f, 1.0f);
			aiQuaternion rotation(1.0f, 0.0f, 0.0f, 0.0f);
			aiVector3D position(0.0f, 0.0f, 0.0f);
			boneIt->second.AnimationMatrix.Decompose(scale, rotation, position);

			aiQuaternion appendRotation(1.0f, 0.0f, 0.0f, 0.0f);
			aiVector3D appendPosition(0.0f, 0.0f, 0.0f);
			auto appendResultIt = appendResults.find(constraint.AppendBoneName);
			if (!constraint.Local && appendResultIt != appendResults.end())
			{
				appendRotation = appendResultIt->second.Rotation;
				appendPosition = appendResultIt->second.Translation;
			}
			else
			{
				getLocalAnimationDelta(appendIt->second, appendRotation, appendPosition);
			}

			PmxAppendResult appendResult{};
			if (constraint.InheritRotation)
			{
				aiQuaternion weightedRotation;
				aiQuaternion::Interpolate(weightedRotation,
					aiQuaternion(1.0f, 0.0f, 0.0f, 0.0f),
					appendRotation,
					clamp(fabsf(constraint.Weight), 0.0f, 1.0f));
				weightedRotation.Normalize();
				if (constraint.Weight < 0.0f)
				{
					weightedRotation.Conjugate();
				}
				rotation = rotation * weightedRotation;
				rotation.Normalize();
				appendResult.Rotation = weightedRotation;
			}

			if (constraint.InheritTranslation)
			{
				appendResult.Translation = appendPosition * constraint.Weight;
				position += appendResult.Translation;
			}

			boneIt->second.AnimationMatrix = aiMatrix4x4(scale, rotation, position);
			appendResults[constraint.BoneName] = appendResult;
			return true;
		};

	auto solveIk = [&](const PmxIkConstraint& constraint)
		{
			if (!IsVmdIkEnabled(animation, constraint.BoneName, timeSeconds) ||
				m_Bone.find(constraint.BoneName) == m_Bone.end() ||
				m_Bone.find(constraint.TargetBoneName) == m_Bone.end())
			{
				return false;
			}

			bool changed = false;
			const uint32_t iterationCount = min<uint32_t>(constraint.IterationCount, 64);
			const float maxAngle = constraint.LimitAngle > 0.0f ? constraint.LimitAngle : XM_PIDIV4;
			for (uint32_t iteration = 0; iteration < iterationCount; ++iteration)
			{
				const XMVECTOR goalPosition = getTranslation(constraint.BoneName);
				const XMVECTOR effectorPosition = getTranslation(constraint.TargetBoneName);
				const float currentDistanceSq = XMVectorGetX(XMVector3LengthSq(XMVectorSubtract(goalPosition, effectorPosition)));
				if (currentDistanceSq < 0.000001f)
				{
					break;
				}

				for (const PmxIkLink& link : constraint.Links)
				{
					auto linkBoneIt = m_Bone.find(link.BoneName);
					if (linkBoneIt == m_Bone.end())
					{
						continue;
					}

					const XMVECTOR linkPosition = getTranslation(link.BoneName);
					const XMVECTOR toEffector = XMVectorSubtract(getTranslation(constraint.TargetBoneName), linkPosition);
					const XMVECTOR toGoal = XMVectorSubtract(getTranslation(constraint.BoneName), linkPosition);
					if (XMVectorGetX(XMVector3LengthSq(toEffector)) < 0.000001f ||
						XMVectorGetX(XMVector3LengthSq(toGoal)) < 0.000001f)
					{
						continue;
					}

					const XMVECTOR effectorDir = XMVector3Normalize(toEffector);
					const XMVECTOR goalDir = XMVector3Normalize(toGoal);
					float dot = XMVectorGetX(XMVector3Dot(effectorDir, goalDir));
					dot = clamp(dot, -1.0f, 1.0f);

					float angle = acosf(dot);
					if (angle < 0.00001f)
					{
						continue;
					}
					angle = min(angle, maxAngle);

					XMVECTOR axis = XMVector3Cross(effectorDir, goalDir);
					if (XMVectorGetX(XMVector3LengthSq(axis)) < 0.000001f)
					{
						continue;
					}
					axis = XMVector3Normalize(axis);

					const XMMATRIX parentGlobal = getParentGlobal(link.BoneName);
					XMVECTOR determinant = XMMatrixDeterminant(parentGlobal);
					const XMMATRIX inverseParent = XMMatrixInverse(&determinant, parentGlobal);
					XMVECTOR localAxis = XMVector3TransformNormal(axis, inverseParent);
					if (XMVectorGetX(XMVector3LengthSq(localAxis)) < 0.000001f)
					{
						continue;
					}
					localAxis = XMVector3Normalize(localAxis);
					if (!applyIkLinkLimit(link, localAxis, angle))
					{
						continue;
					}

					const XMVECTOR deltaRotation = XMQuaternionRotationAxis(localAxis, angle);

					aiVector3D scale(1.0f, 1.0f, 1.0f);
					aiQuaternion rotation(1.0f, 0.0f, 0.0f, 0.0f);
					aiVector3D position(0.0f, 0.0f, 0.0f);
					linkBoneIt->second.AnimationMatrix.Decompose(scale, rotation, position);

					const XMVECTOR currentRotation = XMVectorSet(rotation.x, rotation.y, rotation.z, rotation.w);
					XMVECTOR updatedRotation = XMQuaternionMultiply(currentRotation, deltaRotation);
					updatedRotation = XMQuaternionNormalize(updatedRotation);

					XMFLOAT4 storedRotation{};
					XMStoreFloat4(&storedRotation, updatedRotation);
					aiQuaternion aiUpdatedRotation(storedRotation.w, storedRotation.x, storedRotation.y, storedRotation.z);
					aiUpdatedRotation.Normalize();
					linkBoneIt->second.AnimationMatrix = aiMatrix4x4(scale, aiUpdatedRotation, position);
					changed = true;

					rebuildGlobals();
				}
			}
			return changed;
		};

	struct OrderedTransformStep
	{
		bool IsIk = false;
		size_t Index = 0;
		int32_t DeformDepth = 0;
		uint32_t BoneOrder = 0;
	};

	vector<OrderedTransformStep> steps;
	steps.reserve(m_PmxAppendConstraints.size() + m_PmxIkConstraints.size());
	for (size_t i = 0; i < m_PmxAppendConstraints.size(); ++i)
	{
		const auto& c = m_PmxAppendConstraints[i];
		steps.push_back({ false, i, c.DeformDepth, c.BoneOrder });
	}
	for (size_t i = 0; i < m_PmxIkConstraints.size(); ++i)
	{
		const auto& c = m_PmxIkConstraints[i];
		steps.push_back({ true, i, c.DeformDepth, c.BoneOrder });
	}
	sort(steps.begin(), steps.end(), [](const OrderedTransformStep& lhs, const OrderedTransformStep& rhs)
		{
			if (lhs.DeformDepth != rhs.DeformDepth)
			{
				return lhs.DeformDepth < rhs.DeformDepth;
			}
			if (lhs.BoneOrder != rhs.BoneOrder)
			{
				return lhs.BoneOrder < rhs.BoneOrder;
			}
			return !lhs.IsIk && rhs.IsIk;
		});

	rebuildGlobals();
	for (const OrderedTransformStep& step : steps)
	{
		const bool changed = step.IsIk
			? solveIk(m_PmxIkConstraints[step.Index])
			: applyAppend(m_PmxAppendConstraints[step.Index]);
		if (changed)
		{
			rebuildGlobals();
		}
		
	}
	logged = true;
}

void AnimationModelResource::SampleVmdBone(const VmdAnimation* animation, const string& boneName, float timeSeconds,
	aiQuaternion& outRotation, aiVector3D& outPosition) const
{
	outRotation = aiQuaternion(1.0f, 0.0f, 0.0f, 0.0f);
	outPosition = aiVector3D(0.0f, 0.0f, 0.0f);

	if (!animation)
	{
		return;
	}

	auto trackIt = animation->BoneTracks.find(boneName);
	if (trackIt == animation->BoneTracks.end() || trackIt->second.empty())
	{
		return;
	}

	const vector<VmdKeyframe>& keys = trackIt->second;
	float currentFrame = max(0.0f, timeSeconds) * 30.0f;
	if (animation->MaxFrame > 0)
	{
		currentFrame = fmod(currentFrame, static_cast<float>(animation->MaxFrame) + 1.0f);
	}

	auto nextIt = lower_bound(keys.begin(), keys.end(), currentFrame,
		[](const VmdKeyframe& key, float frame)
		{
			return static_cast<float>(key.Frame) < frame;
		});

	if (nextIt == keys.begin())
	{
		outRotation = nextIt->Rotation;
		outPosition = nextIt->Position;
		return;
	}

	if (nextIt == keys.end())
	{
		outRotation = keys.back().Rotation;
		outPosition = keys.back().Position;
		return;
	}

	const VmdKeyframe& next = *nextIt;
	const VmdKeyframe& prev = *(nextIt - 1);
	if (next.Frame == prev.Frame)
	{
		outRotation = next.Rotation;
		outPosition = next.Position;
		return;
	}

	const float linearFactor = clamp(
		(currentFrame - static_cast<float>(prev.Frame)) / static_cast<float>(next.Frame - prev.Frame),
		0.0f, 1.0f);
	const float factor = GetYFromXOnBezier(linearFactor, next.InterpolationP1, next.InterpolationP2, 12);
	outPosition = prev.Position * (1.0f - factor) + next.Position * factor;
	aiQuaternion::Interpolate(outRotation, prev.Rotation, next.Rotation, factor);
	outRotation.Normalize();
}

void AnimationModelResource::UpdateVmdBoneMatrices(const VmdAnimation* animation1, float frame1,
	const VmdAnimation* animation2, float frame2, float blendRate)
{
	if (!m_AiScene)
	{
		return;
	}

	const VmdAnimation* primaryAnimation = animation1 ? animation1 : animation2;
	const VmdAnimation* secondaryAnimation = animation2 ? animation2 : primaryAnimation;
	if (!primaryAnimation)
	{
		return;
	}

	const float safeBlendRate = clamp(blendRate, 0.0f, 1.0f);
	for (auto& pair : m_Bone)
	{
		Bone* bonePtr = &pair.second;
		aiQuaternion rotation1(1.0f, 0.0f, 0.0f, 0.0f);
		aiVector3D pos1(0.0f, 0.0f, 0.0f);
		aiQuaternion rotation2(1.0f, 0.0f, 0.0f, 0.0f);
		aiVector3D pos2(0.0f, 0.0f, 0.0f);

		SampleVmdBone(primaryAnimation, pair.first, frame1, rotation1, pos1);
		SampleVmdBone(secondaryAnimation, pair.first, frame2, rotation2, pos2);

		const aiVector3D pos = pos1 * (1.0f - safeBlendRate) + pos2 * safeBlendRate;

		aiQuaternion rotation;
		aiQuaternion::Interpolate(rotation, rotation1, rotation2, safeBlendRate);
		rotation.Normalize();

		aiVector3D baseScale(1.0f, 1.0f, 1.0f);
		aiQuaternion baseRotation(1.0f, 0.0f, 0.0f, 0.0f);
		aiVector3D basePosition(0.0f, 0.0f, 0.0f);
		bonePtr->BindLocalMatrix.Decompose(baseScale, baseRotation, basePosition);

		aiQuaternion localRotation = baseRotation * rotation;
		localRotation.Normalize();
		bonePtr->AnimationMatrix = aiMatrix4x4(baseScale, localRotation, basePosition + pos);
	}

	ApplyVmdMorphs(primaryAnimation, frame1);
	ApplyPmxOrderedTransforms(primaryAnimation, frame1);
	UpdateBoneMatrix(m_AiScene->mRootNode, MakeAiIdentityMatrix());
	WriteBoneMatricesToBuffer();
}

bool AnimationModelResource::IsVmdIkEnabled(const VmdAnimation* animation, const string& ikBoneName, float timeSeconds) const
{
	if (!animation)
	{
		return true;
	}

	auto trackIt = animation->IkTracks.find(ikBoneName);
	if (trackIt == animation->IkTracks.end() || trackIt->second.empty())
	{
		return true;
	}

	float currentFrame = max(0.0f, timeSeconds) * 30.0f;
	if (animation->MaxFrame > 0)
	{
		currentFrame = fmod(currentFrame, static_cast<float>(animation->MaxFrame) + 1.0f);
	}

	const vector<VmdIkKeyframe>& keys = trackIt->second;
	auto nextIt = upper_bound(keys.begin(), keys.end(), currentFrame,
		[](float frame, const VmdIkKeyframe& key)
		{
			return frame < static_cast<float>(key.Frame);
		});
	if (nextIt == keys.begin())
	{
		return keys.front().Enable;
	}
	return (nextIt - 1)->Enable;
}

void AnimationModelResource::ApplyPmxIk(const VmdAnimation* animation, float timeSeconds)
{
	if (!m_AiScene || m_PmxIkConstraints.empty())
	{
		return;
	}

	auto aiToXm = [](const aiMatrix4x4& src)
		{
			return XMMatrixSet(
				src.a1, src.a2, src.a3, src.a4,
				src.b1, src.b2, src.b3, src.b4,
				src.c1, src.c2, src.c3, src.c4,
				src.d1, src.d2, src.d3, src.d4);
		};

	unordered_map<string, XMFLOAT4X4> globalMatrices;
	auto rebuildGlobals = [&]()
		{
			globalMatrices.clear();
			auto buildRecursive = [&](auto&& self, aiNode* node, XMMATRIX parentMatrix) -> void
				{
					if (!node)
					{
						return;
					}

					const string nodeName = node->mName.C_Str();
					XMMATRIX localMatrix = aiToXm(node->mTransformation);
					auto boneIt = m_Bone.find(nodeName);
					if (boneIt != m_Bone.end())
					{
						localMatrix = aiToXm(boneIt->second.AnimationMatrix);
					}

					const XMMATRIX worldMatrix = XMMatrixMultiply(parentMatrix, localMatrix);
					XMFLOAT4X4 storedWorld{};
					XMStoreFloat4x4(&storedWorld, worldMatrix);
					globalMatrices[nodeName] = storedWorld;

					for (unsigned int n = 0; n < node->mNumChildren; ++n)
					{
						self(self, node->mChildren[n], worldMatrix);
					}
				};
			buildRecursive(buildRecursive, m_AiScene->mRootNode, XMMatrixIdentity());
		};

	auto loadGlobal = [&](const string& boneName)
		{
			auto it = globalMatrices.find(boneName);
			return it != globalMatrices.end() ? XMLoadFloat4x4(&it->second) : XMMatrixIdentity();
		};

	auto getTranslation = [&](const string& boneName)
		{
			auto it = globalMatrices.find(boneName);
			if (it == globalMatrices.end())
			{
				return XMVectorZero();
			}
			const XMFLOAT4X4& matrix = it->second;
			return XMVectorSet(matrix._41, matrix._42, matrix._43, 1.0f);
		};

	auto getParentGlobal = [&](const string& boneName)
		{
			auto parentIt = m_BoneParentMap.find(boneName);
			if (parentIt == m_BoneParentMap.end())
			{
				return XMMatrixIdentity();
			}
			return loadGlobal(parentIt->second);
		};

	auto applyIkLinkLimit = [](const PmxIkLink& link, XMVECTOR& localAxis, float& angle) -> bool
		{
			if (!link.HasLimit)
			{
				return true;
			}

			const float component[3] =
			{
				XMVectorGetX(localAxis),
				XMVectorGetY(localAxis),
				XMVectorGetZ(localAxis),
			};
			const float minLimit[3] = { link.LimitMin.x, link.LimitMin.y, link.LimitMin.z };
			const float maxLimit[3] = { link.LimitMax.x, link.LimitMax.y, link.LimitMax.z };

			float limitedComponent[3] = {};
			float maxAllowedAngle = 0.0f;
			int fallbackAxis = -1;
			float fallbackAxisLimit = 0.0f;
			for (int axis = 0; axis < 3; ++axis)
			{
				float low = minLimit[axis];
				float high = maxLimit[axis];
				if (low > high)
				{
					swap(low, high);
				}

				const float axisLimit = max(fabsf(low), fabsf(high));
				const bool allowsAxis = fabsf(high - low) > 0.00001f && axisLimit > 0.00001f;
				if (!allowsAxis)
				{
					continue;
				}

				float signedComponent = component[axis];
				const bool allowsPositive = high > 0.00001f;
				const bool allowsNegative = low < -0.00001f;
				if (allowsPositive && !allowsNegative)
				{
					signedComponent = fabsf(signedComponent);
				}
				else if (!allowsPositive && allowsNegative)
				{
					signedComponent = -fabsf(signedComponent);
				}

				limitedComponent[axis] = signedComponent;
				maxAllowedAngle = max(maxAllowedAngle, axisLimit);
				if (axisLimit > fallbackAxisLimit)
				{
					fallbackAxis = axis;
					fallbackAxisLimit = axisLimit;
				}
			}

			if (maxAllowedAngle <= 0.00001f)
			{
				return false;
			}

			XMVECTOR limitedAxis = XMVectorSet(
				limitedComponent[0],
				limitedComponent[1],
				limitedComponent[2],
				0.0f);

			if (XMVectorGetX(XMVector3LengthSq(limitedAxis)) < 0.000001f)
			{
				float fallbackComponent[3] = {};
				float low = minLimit[fallbackAxis];
				float high = maxLimit[fallbackAxis];
				if (low > high)
				{
					swap(low, high);
				}

				const bool allowsPositive = high > 0.00001f;
				const bool allowsNegative = low < -0.00001f;
				float sign = component[fallbackAxis] < 0.0f ? -1.0f : 1.0f;
				if (allowsPositive && !allowsNegative)
				{
					sign = 1.0f;
				}
				else if (!allowsPositive && allowsNegative)
				{
					sign = -1.0f;
				}
				fallbackComponent[fallbackAxis] = sign;
				limitedAxis = XMVectorSet(
					fallbackComponent[0],
					fallbackComponent[1],
					fallbackComponent[2],
					0.0f);
			}

			localAxis = XMVector3Normalize(limitedAxis);
			angle = min(angle, maxAllowedAngle);
			return true;
		};

	rebuildGlobals();
	for (const PmxIkConstraint& constraint : m_PmxIkConstraints)
	{
		if (!IsVmdIkEnabled(animation, constraint.BoneName, timeSeconds) ||
			m_Bone.find(constraint.BoneName) == m_Bone.end() ||
			m_Bone.find(constraint.TargetBoneName) == m_Bone.end())
		{
			continue;
		}

		const uint32_t iterationCount = min<uint32_t>(constraint.IterationCount, 64);
		const float maxAngle = constraint.LimitAngle > 0.0f ? constraint.LimitAngle : XM_PIDIV4;
		for (uint32_t iteration = 0; iteration < iterationCount; ++iteration)
		{
			const XMVECTOR goalPosition = getTranslation(constraint.BoneName);
			const XMVECTOR effectorPosition = getTranslation(constraint.TargetBoneName);
			const float currentDistanceSq = XMVectorGetX(XMVector3LengthSq(XMVectorSubtract(goalPosition, effectorPosition)));
			if (currentDistanceSq < 0.000001f)
			{
				break;
			}

			for (const PmxIkLink& link : constraint.Links)
			{
				auto linkBoneIt = m_Bone.find(link.BoneName);
				if (linkBoneIt == m_Bone.end())
				{
					continue;
				}

				const XMVECTOR linkPosition = getTranslation(link.BoneName);
				const XMVECTOR toEffector = XMVectorSubtract(getTranslation(constraint.TargetBoneName), linkPosition);
				const XMVECTOR toGoal = XMVectorSubtract(getTranslation(constraint.BoneName), linkPosition);
				if (XMVectorGetX(XMVector3LengthSq(toEffector)) < 0.000001f ||
					XMVectorGetX(XMVector3LengthSq(toGoal)) < 0.000001f)
				{
					continue;
				}

				const XMVECTOR effectorDir = XMVector3Normalize(toEffector);
				const XMVECTOR goalDir = XMVector3Normalize(toGoal);
				float dot = XMVectorGetX(XMVector3Dot(effectorDir, goalDir));
				dot = clamp(dot, -1.0f, 1.0f);

				float angle = acosf(dot);
				if (angle < 0.00001f)
				{
					continue;
				}
				angle = min(angle, maxAngle);

				XMVECTOR axis = XMVector3Cross(effectorDir, goalDir);
				if (XMVectorGetX(XMVector3LengthSq(axis)) < 0.000001f)
				{
					continue;
				}
				axis = XMVector3Normalize(axis);

				const XMMATRIX parentGlobal = getParentGlobal(link.BoneName);
				XMVECTOR determinant = XMMatrixDeterminant(parentGlobal);
				const XMMATRIX inverseParent = XMMatrixInverse(&determinant, parentGlobal);
				XMVECTOR localAxis = XMVector3TransformNormal(axis, inverseParent);
				if (XMVectorGetX(XMVector3LengthSq(localAxis)) < 0.000001f)
				{
					continue;
				}
				localAxis = XMVector3Normalize(localAxis);
				if (!applyIkLinkLimit(link, localAxis, angle))
				{
					continue;
				}

				const XMVECTOR deltaRotation = XMQuaternionRotationAxis(localAxis, angle);

				aiVector3D scale(1.0f, 1.0f, 1.0f);
				aiQuaternion rotation(1.0f, 0.0f, 0.0f, 0.0f);
				aiVector3D position(0.0f, 0.0f, 0.0f);
				linkBoneIt->second.AnimationMatrix.Decompose(scale, rotation, position);

				const XMVECTOR currentRotation = XMVectorSet(rotation.x, rotation.y, rotation.z, rotation.w);
				XMVECTOR updatedRotation = XMQuaternionMultiply(currentRotation, deltaRotation);
				updatedRotation = XMQuaternionNormalize(updatedRotation);

				XMFLOAT4 storedRotation{};
				XMStoreFloat4(&storedRotation, updatedRotation);
				aiQuaternion aiUpdatedRotation(storedRotation.w, storedRotation.x, storedRotation.y, storedRotation.z);
				aiUpdatedRotation.Normalize();
				linkBoneIt->second.AnimationMatrix = aiMatrix4x4(scale, aiUpdatedRotation, position);

				rebuildGlobals();
			}
		}
	}
}

void AnimationModelResource::UpdateBoneMatrices(const char* animName1, float frame1,
	const char* animName2, float frame2, float blendRate)
{
	if (!m_AiScene)
	{
		return;
	}

	const string animationName1 = animName1 ? animName1 : "";
	const string animationName2 = animName2 ? animName2 : "";

	const VmdAnimation* vmdAnimation1 = nullptr;
	const VmdAnimation* vmdAnimation2 = nullptr;
	auto vmdIt1 = m_VmdAnimations.find(animationName1);
	if (vmdIt1 != m_VmdAnimations.end())
	{
		vmdAnimation1 = &vmdIt1->second;
	}
	auto vmdIt2 = m_VmdAnimations.find(animationName2);
	if (vmdIt2 != m_VmdAnimations.end())
	{
		vmdAnimation2 = &vmdIt2->second;
	}
	if (vmdAnimation1 || vmdAnimation2)
	{
		UpdateVmdBoneMatrices(vmdAnimation1, frame1, vmdAnimation2, frame2, blendRate);
		return;
	}

	aiAnimation* animation1 = GetAnimation(animationName1);
	aiAnimation* animation2 = GetAnimation(animationName2);

	if (!animation1 && !animation2)
	{
		return;
	}

	auto sampleRotationKey = [](aiNodeAnim* nodeAnim, float timeInTicks, double duration)
		{
			if (!nodeAnim || nodeAnim->mNumRotationKeys == 0)
			{
				return aiQuaternion(1.0f, 0.0f, 0.0f, 0.0f);
			}

			const float t = duration > 0.0 ? fmod(timeInTicks, static_cast<float>(duration)) : timeInTicks;
			const unsigned int keyIndex = static_cast<unsigned int>(max(0.0f, t)) % nodeAnim->mNumRotationKeys;
			return nodeAnim->mRotationKeys[keyIndex].mValue;
		};

	auto samplePositionKey = [](aiNodeAnim* nodeAnim, float timeInTicks, double duration)
		{
			if (!nodeAnim || nodeAnim->mNumPositionKeys == 0)
			{
				return aiVector3D(0.0f, 0.0f, 0.0f);
			}

			const float t = duration > 0.0 ? fmod(timeInTicks, static_cast<float>(duration)) : timeInTicks;
			const unsigned int keyIndex = static_cast<unsigned int>(max(0.0f, t)) % nodeAnim->mNumPositionKeys;
			return nodeAnim->mPositionKeys[keyIndex].mValue;
		};

	for (auto pair : m_Bone)
	{
		Bone* bonePtr = &m_Bone[pair.first];
		aiNodeAnim* nodeAnim1 = FindNodeAnimChannel(animation1, pair.first);
		aiNodeAnim* nodeAnim2 = FindNodeAnimChannel(animation2, pair.first);

		const float ticksPerSecond1 = (animation1 && animation1->mTicksPerSecond != 0)
			? static_cast<float>(animation1->mTicksPerSecond)
			: 25.0f;
		const float ticksPerSecond2 = (animation2 && animation2->mTicksPerSecond != 0)
			? static_cast<float>(animation2->mTicksPerSecond)
			: 25.0f;

		const float timeInTicks1 = frame1 * ticksPerSecond1;
		const float timeInTicks2 = frame2 * ticksPerSecond2;

		aiQuaternion rotation1 = sampleRotationKey(nodeAnim1, timeInTicks1, animation1 ? animation1->mDuration : 0.0);
		aiVector3D pos1 = samplePositionKey(nodeAnim1, timeInTicks1, animation1 ? animation1->mDuration : 0.0);
		aiQuaternion rotation2 = sampleRotationKey(nodeAnim2, timeInTicks2, animation2 ? animation2->mDuration : 0.0);
		aiVector3D pos2 = samplePositionKey(nodeAnim2, timeInTicks2, animation2 ? animation2->mDuration : 0.0);

		const aiVector3D pos = pos1 * (1.f - blendRate) + pos2 * blendRate;

		aiQuaternion rotation;
		aiQuaternion::Interpolate(rotation, rotation1, rotation2, blendRate);

		bonePtr->AnimationMatrix = aiMatrix4x4(aiVector3D(1.0f, 1.0f, 1.0f), rotation, pos);
	}

	UpdateBoneMatrix(m_AiScene->mRootNode, MakeAiIdentityMatrix());
	WriteBoneMatricesToBuffer();
}

void AnimationModelResource::DispatchGpuSkinning(ID3D12GraphicsCommandList* pCommandList)
{
	if (!m_SkinningDescHeap || !RendererShader::GetSkinningRootSignature() || !PsoManager::GetSkinningPso()) return;

	pCommandList->SetComputeRootSignature(RendererShader::GetSkinningRootSignature());
	pCommandList->SetPipelineState(PsoManager::GetSkinningPso());

	ID3D12DescriptorHeap* heaps[] = { m_SkinningDescHeap.Get() };
	pCommandList->SetDescriptorHeaps(_countof(heaps), heaps);

	UINT descSize = m_pDevice->GetDescriptorHandleIncrementSize(D3D12_DESCRIPTOR_HEAP_TYPE_CBV_SRV_UAV);

	for (UINT m = 0; m < m_Meshes.size(); m++)
	{
		if (m_Meshes[m].VertexCount == 0) continue;
		const UINT descriptorBase = m * m_kSKINNING_DESCRIPTORS_PER_MESH;

		CD3DX12_GPU_DESCRIPTOR_HANDLE srvInputHandle(m_SkinningDescHeap->GetGPUDescriptorHandleForHeapStart(), m_Meshes[m].SrvInputVertexIndex, descSize);
		pCommandList->SetComputeRootDescriptorTable(0, srvInputHandle);

		CD3DX12_GPU_DESCRIPTOR_HANDLE srvBoneHandle(m_SkinningDescHeap->GetGPUDescriptorHandleForHeapStart(), descriptorBase + m_kBONE_SRV_OFFSET, descSize);
		pCommandList->SetComputeRootDescriptorTable(1, srvBoneHandle);

		CD3DX12_GPU_DESCRIPTOR_HANDLE uavOutputHandle(m_SkinningDescHeap->GetGPUDescriptorHandleForHeapStart(), m_Meshes[m].UavOutputVertexIndex, descSize);
		pCommandList->SetComputeRootDescriptorTable(2, uavOutputHandle);

		UINT threadGroups = (m_Meshes[m].VertexCount + 63) / 64;
		pCommandList->Dispatch(threadGroups, 1, 1);

		for (int mode = 0; mode < ToonOutlineBuilder::kModeCount; ++mode)
		{
			if (m_Meshes[m].TeoVertexCounts[mode] == 0 ||
				!m_Meshes[m].TeoInputVertexBuffers[mode] ||
				!m_Meshes[m].TeoVertexBuffers[mode])
			{
				continue;
			}

			CD3DX12_GPU_DESCRIPTOR_HANDLE teoSrvInputHandle(
				m_SkinningDescHeap->GetGPUDescriptorHandleForHeapStart(),
				m_Meshes[m].SrvTeoInputVertexIndices[mode],
				descSize);
			pCommandList->SetComputeRootDescriptorTable(0, teoSrvInputHandle);

			CD3DX12_GPU_DESCRIPTOR_HANDLE teoUavOutputHandle(
				m_SkinningDescHeap->GetGPUDescriptorHandleForHeapStart(),
				m_Meshes[m].UavTeoOutputVertexIndices[mode],
				descSize);
			pCommandList->SetComputeRootDescriptorTable(2, teoUavOutputHandle);

			UINT teoThreadGroups = (m_Meshes[m].TeoVertexCounts[mode] + 63) / 64;
			pCommandList->Dispatch(teoThreadGroups, 1, 1);
		}
	}

	if (ID3D12DescriptorHeap* cbvHeap = RendererResource::GetCbvHeap())
	{
		ID3D12DescriptorHeap* rendererHeaps[] = { cbvHeap };
		pCommandList->SetDescriptorHeaps(_countof(rendererHeaps), rendererHeaps);
	}
}

void AnimationModelResource::Uninit()
{
	if (m_BoneBuffer && m_pBoneBufferMapped)
	{
		m_BoneBuffer->Unmap(0, nullptr);
		m_pBoneBufferMapped = nullptr;
	}

	m_Meshes.clear();
	m_DeformVertex.clear();
	m_GpuSkinVertices.clear();
	m_BaseGpuSkinVertices.clear();
	m_Bone.clear();
	m_BoneNames.clear();
	m_BoneIndexMap.clear();
	m_BoneParentMap.clear();
	m_PmxAppendConstraints.clear();
	m_PmxIkConstraints.clear();
	m_PmxBaseVertices.clear();
	m_PmxBaseNormals.clear();
	m_PmxBaseTexCoords.clear();
	m_PmxMorphs.clear();
	m_PmxMorphIndexMap.clear();
	m_PmxVertexToMeshVertices.clear();
	m_BoneMatricesScratch.clear();
	m_HasAppliedVmdMorphs = false;
	m_AabbCenter = {};
	m_AabbExtents = {};

	if (m_AiScene)
	{
		aiReleaseImport(m_AiScene);
		m_AiScene = nullptr;
	}

	for (auto& pair : m_Animation)
	{
		aiReleaseImport(pair.second);
	}
	m_Animation.clear();
	m_VmdAnimations.clear();
}
